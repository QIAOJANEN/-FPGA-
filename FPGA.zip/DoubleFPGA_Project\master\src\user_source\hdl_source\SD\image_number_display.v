// Physical six-digit active-low display; last two scan positions show 01..14.
// 00 denotes that the first image has not yet been committed.
module image_number_display(
    input clk, rst_n,
    input [3:0] image_index,
    input image_valid,
    output [5:0] seg_sel,
    output [7:0] seg_data
);
reg [4:0] mailbox_meta, mailbox_sync, mailbox_previous, mailbox_stable;
always @(posedge clk or negedge rst_n) begin
    if(!rst_n) begin
        mailbox_meta<=0;mailbox_sync<=0;mailbox_previous<=0;mailbox_stable<=0;
    end else begin
        mailbox_meta<={image_valid,image_index};
        mailbox_sync<=mailbox_meta;
        mailbox_previous<=mailbox_sync;
        if(mailbox_previous==mailbox_sync) mailbox_stable<=mailbox_sync;
    end
end
wire [4:0] number=(mailbox_stable[4] && mailbox_stable[3:0]<14) ?
                    ({1'b0,mailbox_stable[3:0]}+5'd1) : 5'd0;
wire [3:0] tens=(number>=10) ? 4'd1 : 4'd0;
wire [3:0] ones=(number>=10) ? (number-5'd10) : number[3:0];
wire [6:0] tens_segments,ones_segments;
seg_decoder u_tens(.bin_data(tens),.seg_data(tens_segments));
seg_decoder u_ones(.bin_data(ones),.seg_data(ones_segments));
seg_scan u_scan(
    .clk(clk),.rst_n(rst_n),.seg_sel(seg_sel),.seg_data(seg_data),
    .seg_data_0(8'hff),.seg_data_1(8'hff),.seg_data_2(8'hff),.seg_data_3(8'hff),
    .seg_data_4({1'b1,tens_segments}),.seg_data_5({1'b1,ones_segments}));
endmodule
