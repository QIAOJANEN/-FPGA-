param(
    [string]$TdCommand
)

$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot

# ---- 1. locate Tang Dynasty command line tool ----
if (-not $TdCommand) {
    $cands = @()
    $cands = $cands + (Get-ChildItem 'C:\Anlogic\TD_*\bin\td_commands_prompt.exe' -ErrorAction SilentlyContinue)
    $cands = $cands + (Get-ChildItem 'D:\Anlogic\TD_*\bin\td_commands_prompt.exe' -ErrorAction SilentlyContinue)
    $cands = $cands + (Get-ChildItem 'E:\anLUFPGA\bin\td_commands_prompt.exe' -ErrorAction SilentlyContinue)
    $cands = $cands + (Get-ChildItem 'C:\Program Files\Anlogic\TD_*\bin\td_commands_prompt.exe' -ErrorAction SilentlyContinue)
    if ($cands.Count -gt 0) {
        $sorted = $cands | Sort-Object FullName -Descending
        $TdCommand = $sorted[0].FullName
    }
}

if (-not $TdCommand) {
    Write-Host 'Cannot find td_commands_prompt.exe.' -ForegroundColor Yellow
    Write-Host 'Install Tang Dynasty 6.2 first, or pass the full path:' -ForegroundColor Yellow
    Write-Host '  .\build_all.ps1 -TdCommand "C:\Anlogic\TD_6.2.1_Engineer_6.2.168.116\bin\td_commands_prompt.exe"' -ForegroundColor Yellow
    throw 'TD command tool not found'
}
if (-not (Test-Path -LiteralPath $TdCommand)) {
    throw ('TD command tool not found: ' + $TdCommand)
}
Write-Host ('Using TD: ' + $TdCommand)

# ---- 2. TD tcl entry does not accept script paths with spaces or non-ASCII chars ----
$tmpDir = Join-Path $env:TEMP ('td_build_' + [System.Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $tmpDir | Out-Null

# build slave first, then master
$relList = 'slave\src\td_project', 'master\src\td_project'

foreach ($rel in $relList) {
    $project = Join-Path $projectRoot $rel
    if (-not (Test-Path -LiteralPath $project)) {
        throw ('Project directory not found: ' + $project)
    }
    Write-Host ('=== Build: ' + $project)
    Push-Location $project
    try {
        $srcTcl = Join-Path $project 'build_bitstream.tcl'
        if (-not (Test-Path -LiteralPath $srcTcl)) {
            throw ('Missing build script: ' + $srcTcl)
        }
        $name = [System.Guid]::NewGuid().ToString('N') + '.tcl'
        $tmpTcl = Join-Path $tmpDir $name
        Copy-Item -LiteralPath $srcTcl -Destination $tmpTcl -Force
        $tmpTclForTd = $tmpTcl -replace '\\', '/'
        & $TdCommand $tmpTclForTd
        if ($LASTEXITCODE -ne 0) {
            throw ('TD build failed (exit ' + $LASTEXITCODE + '): ' + $project)
        }
    }
    finally {
        Pop-Location
    }
}

Remove-Item -LiteralPath $tmpDir -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ''
Write-Host 'Done. bit files are in each td_project folder; prebuilt ones are in output\'
