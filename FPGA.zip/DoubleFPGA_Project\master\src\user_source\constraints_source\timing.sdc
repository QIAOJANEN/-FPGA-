# HX4S20C, input 50MHz. Keep all active video/memory clocks timed together.
create_clock -name clk -period 20 -waveform {0 10} [get_ports {clk}]
derive_clocks
rename_clock -name {sd_card_clk} -source [get_ports {clk}] -master_clock {clk} [get_pins {sys_pll_m0/pll_inst.clkc[0]}]
rename_clock -name {ext_mem_clk} -source [get_ports {clk}] -master_clock {clk} [get_pins {sys_pll_m0/pll_inst.clkc[1]}]
rename_clock -name {video_clk} -source [get_ports {clk}] -master_clock {clk} [get_pins {video_pll_m0/pll_inst.clkc[0]}]
rename_clock -name {hdmi_5x_clk} -source [get_ports {clk}] -master_clock {clk} [get_pins {video_pll_m0/pll_inst.clkc[1]}]

# The video PLL and system PLL have no guaranteed phase relationship. Their
# crossings use explicit synchronizers/handshakes. Suppress only the impossible
# inter-PLL hold checks while retaining setup analysis for routing quality.
set_false_path -hold -from [get_clocks {video_clk hdmi_5x_clk}] -to [get_clocks {sd_card_clk ext_mem_clk}]
set_false_path -hold -from [get_clocks {sd_card_clk ext_mem_clk}] -to [get_clocks {video_clk hdmi_5x_clk}]

# Pixel and HDMI serializer clocks run simultaneously and share a PLL.
# Do NOT declare them exclusive: their data paths must be analyzed.
# Audio payload is disabled and the unused audio output clock is optimized out.
# No audio clock rename/group is issued for a nonexistent net.

# Board-specific input/output delay budgets are not supplied by this project.
# Reported internal timing closure does not replace SD/HDMI hardware validation.
