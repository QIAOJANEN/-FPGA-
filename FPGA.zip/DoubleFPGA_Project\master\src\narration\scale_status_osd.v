// SW3 scale controller and top-left status OSD: 自适应缩放 640x480 etc.
module scale_status_osd(
 input clk,input rst,input enable,input key_zoom_in_n,input key_zoom_out_n,
 input vs_in,input de_in,input [23:0] rgb_in,
 output reg [2:0] scale_level,output reg change_toggle,
 output reg vs_out,output reg de_out,output reg [23:0] rgb_out);
 wire zoom_in,zoom_out;
 adjust_key_debounce k0(.clk(clk),.rst(rst),.key_n(key_zoom_in_n),.pulse(zoom_in));
 adjust_key_debounce k1(.clk(clk),.rst(rst),.key_n(key_zoom_out_n),.pulse(zoom_out));
 reg enable_d;
 always @(posedge clk or posedge rst)begin
  if(rst)begin scale_level<=0;change_toggle<=0;enable_d<=0;end
  else begin
   enable_d<=enable;
   if(!enable&&enable_d&&scale_level!=0)begin scale_level<=0;change_toggle<=~change_toggle;end
   else if(enable)begin
    if(zoom_in&&scale_level>0)begin scale_level<=scale_level-1'b1;change_toggle<=~change_toggle;end
    else if(zoom_out&&scale_level<4)begin scale_level<=scale_level+1'b1;change_toggle<=~change_toggle;end
   end
  end
 end

 reg [9:0] width,height;reg [3:0] wh,wt,wo,hh,ht,ho;
 always @* begin case(scale_level)
  1:begin width=576;height=432;wh=5;wt=7;wo=6;hh=4;ht=3;ho=2;end
  2:begin width=512;height=384;wh=5;wt=1;wo=2;hh=3;ht=8;ho=4;end
  3:begin width=448;height=336;wh=4;wt=4;wo=8;hh=3;ht=3;ho=6;end
  4:begin width=384;height=288;wh=3;wt=8;wo=4;hh=2;ht=8;ho=8;end
  default:begin width=640;height=480;wh=6;wt=4;wo=0;hh=4;ht=8;ho=0;end endcase
 end

 function [4:0] latin_row;
  input [3:0] ch;input [2:0] row;
  begin case(ch)
   0:case(row)0:latin_row=5'b01110;1:latin_row=5'b10001;2:latin_row=5'b10011;3:latin_row=5'b10101;4:latin_row=5'b11001;5:latin_row=5'b10001;default:latin_row=5'b01110;endcase
   1:case(row)0:latin_row=5'b00100;1:latin_row=5'b01100;2:latin_row=5'b00100;3:latin_row=5'b00100;4:latin_row=5'b00100;5:latin_row=5'b00100;default:latin_row=5'b01110;endcase
   2:case(row)0:latin_row=5'b01110;1:latin_row=5'b10001;2:latin_row=5'b00001;3:latin_row=5'b00010;4:latin_row=5'b00100;5:latin_row=5'b01000;default:latin_row=5'b11111;endcase
   3:case(row)0:latin_row=5'b11110;1:latin_row=5'b00001;2:latin_row=5'b00001;3:latin_row=5'b01110;4:latin_row=5'b00001;5:latin_row=5'b00001;default:latin_row=5'b11110;endcase
   4:case(row)0:latin_row=5'b00010;1:latin_row=5'b00110;2:latin_row=5'b01010;3:latin_row=5'b10010;4:latin_row=5'b11111;5:latin_row=5'b00010;default:latin_row=5'b00010;endcase
   5:case(row)0:latin_row=5'b11111;1:latin_row=5'b10000;2:latin_row=5'b10000;3:latin_row=5'b11110;4:latin_row=5'b00001;5:latin_row=5'b00001;default:latin_row=5'b11110;endcase
   6:case(row)0:latin_row=5'b00110;1:latin_row=5'b01000;2:latin_row=5'b10000;3:latin_row=5'b11110;4:latin_row=5'b10001;5:latin_row=5'b10001;default:latin_row=5'b01110;endcase
   7:case(row)0:latin_row=5'b11111;1:latin_row=5'b00001;2:latin_row=5'b00010;3:latin_row=5'b00100;4:latin_row=5'b01000;5:latin_row=5'b01000;default:latin_row=5'b01000;endcase
   8:case(row)0:latin_row=5'b01110;1:latin_row=5'b10001;2:latin_row=5'b10001;3:latin_row=5'b01110;4:latin_row=5'b10001;5:latin_row=5'b10001;default:latin_row=5'b01110;endcase
   9:case(row)0:latin_row=5'b01110;1:latin_row=5'b10001;2:latin_row=5'b10001;3:latin_row=5'b01111;4:latin_row=5'b00001;5:latin_row=5'b00010;default:latin_row=5'b11100;endcase
   default:case(row)0,6:latin_row=0;1:latin_row=5'b10001;2:latin_row=5'b01010;3:latin_row=5'b00100;4:latin_row=5'b01010;5:latin_row=5'b10001;default:latin_row=0;endcase // x
  endcase end
 endfunction

 function [15:0] zh_row;
  input [2:0] ch;input [3:0] row;
  begin case(ch)
   0:case(row)0:zh_row=16'h0300;1:zh_row=16'h0300;2:zh_row=16'h1ff8;3:zh_row=16'h1ff8;4:zh_row=16'h1008;5:zh_row=16'h1008;6:zh_row=16'h1ff8;7:zh_row=16'h1008;8:zh_row=16'h1008;9:zh_row=16'h1ff8;10:zh_row=16'h1008;11:zh_row=16'h1008;12:zh_row=16'h1ff8;13:zh_row=16'h1008;default:zh_row=0;endcase
   1:case(row)0:zh_row=0;1:zh_row=16'h0008;2:zh_row=16'h23f0;3:zh_row=16'h3040;4:zh_row=16'h1040;5:zh_row=16'h07fe;6:zh_row=16'h0040;7:zh_row=16'h7040;8:zh_row=16'h13fc;9:zh_row=16'h120c;10:zh_row=16'h120c;11:zh_row=16'h13fc;12:zh_row=16'h120c;13:zh_row=16'h3c00;14:zh_row=16'h63fe;default:zh_row=0;endcase
   2:case(row)0:zh_row=16'h0080;1:zh_row=16'h0080;2:zh_row=16'h1ffe;3:zh_row=16'h1000;4:zh_row=16'h1000;5:zh_row=16'h108c;6:zh_row=16'h1c88;7:zh_row=16'h3448;8:zh_row=16'h3658;9:zh_row=16'h2210;10:zh_row=16'h2210;11:zh_row=16'h2030;12:zh_row=16'h6ffe;13:zh_row=16'h4ffe;default:zh_row=0;endcase
   3:case(row)0:zh_row=16'h1020;1:zh_row=16'h1020;2:zh_row=16'h23fe;3:zh_row=16'h2282;4:zh_row=16'h48fe;5:zh_row=16'h7918;6:zh_row=16'h1310;7:zh_row=16'h273e;8:zh_row=16'h2126;9:zh_row=16'h7926;10:zh_row=16'h013e;11:zh_row=16'h0126;12:zh_row=16'h7d26;13:zh_row=16'h413e;14:zh_row=16'h0126;default:zh_row=0;endcase
   default:case(row)0:zh_row=16'h1020;1:zh_row=16'h1820;2:zh_row=16'h0840;3:zh_row=16'h7f7e;4:zh_row=16'h104c;5:zh_row=16'h10cc;6:zh_row=16'h1ec8;7:zh_row=16'h1248;8:zh_row=16'h1228;9:zh_row=16'h1228;10:zh_row=16'h3230;11:zh_row=16'h2230;12:zh_row=16'h6268;13:zh_row=16'h4fc6;14:zh_row=16'h0002;default:zh_row=0;endcase
  endcase end
 endfunction

 reg [9:0] x,y;reg vs_d;reg glyph_on;reg [15:0] zr;reg [4:0] lr;
 reg [3:0] digit;reg [2:0] fx,fy;reg [3:0] pos;
 always @* begin
  glyph_on=0;zr=0;lr=0;digit=0;fx=0;fy=0;pos=0;
  if(y>=8&&y<24&&x>=8&&x<88)begin
   pos=(x-8)>>4;zr=zh_row(pos,y-8);glyph_on=zr[15-((x-8)&15)];
  end else if(y>=9&&y<23&&x>=100&&x<170)begin
   pos=(x-100)/10;fx=((x-100)%10)>>1;fy=(y-9)>>1;
   case(pos)
    0:digit=wh;1:digit=wt;2:digit=wo;3:digit=10;
    4:digit=hh;5:digit=ht;default:digit=ho;
   endcase
   lr=latin_row(digit,fy);glyph_on=lr[4-fx];
  end
 end
 always @(posedge clk or posedge rst)begin
  if(rst)begin x<=0;y<=0;vs_d<=0;vs_out<=0;de_out<=0;rgb_out<=0;end
  else begin
   vs_d<=vs_in;if(vs_in&&!vs_d)begin x<=0;y<=0;end
   else if(de_in)begin if(x==639)begin x<=0;if(y<479)y<=y+1'b1;end else x<=x+1'b1;end
   vs_out<=vs_in;de_out<=de_in;
   if(enable&&de_in&&x>=4&&x<176&&y>=4&&y<28)rgb_out<=glyph_on?24'h80ffff:24'h102038;
   else rgb_out<=rgb_in;
  end
 end
endmodule


// Always-on top-left OSD showing the original resolution of the selected museum image.
module resolution_center_osd(
 input clk,input rst,input enable,input [3:0] image_index,
 input vs_in,input de_in,input [23:0] rgb_in,
 output reg vs_out,output reg de_out,output reg [23:0] rgb_out);

 reg [13:0] src_w,src_h;
 always @* begin
  case(image_index)
   4'd0: begin src_w=640;  src_h=480;  end
   4'd1: begin src_w=1400; src_h=1400; end
   4'd2: begin src_w=1443; src_h=1367; end
   4'd3: begin src_w=960;  src_h=640;  end
   4'd4: begin src_w=960;  src_h=641;  end
   4'd5: begin src_w=960;  src_h=640;  end
   4'd6: begin src_w=960;  src_h=1336; end
   4'd7: begin src_w=960;  src_h=1440; end
   4'd8: begin src_w=960;  src_h=1677; end
   4'd9: begin src_w=960;  src_h=1440; end
   4'd10:begin src_w=960;  src_h=396;  end
   4'd11:begin src_w=1920; src_h=1280; end
   4'd12:begin src_w=960;  src_h=720;  end
   default:begin src_w=960; src_h=1276; end
  endcase
 end

 function [4:0] font5x7;
  input [3:0] ch; input [2:0] row;
  begin case(ch)
   0:case(row)0:font5x7=5'b01110;1:font5x7=5'b10001;2:font5x7=5'b10011;3:font5x7=5'b10101;4:font5x7=5'b11001;5:font5x7=5'b10001;default:font5x7=5'b01110;endcase
   1:case(row)0:font5x7=5'b00100;1:font5x7=5'b01100;2:font5x7=5'b00100;3:font5x7=5'b00100;4:font5x7=5'b00100;5:font5x7=5'b00100;default:font5x7=5'b01110;endcase
   2:case(row)0:font5x7=5'b01110;1:font5x7=5'b10001;2:font5x7=5'b00001;3:font5x7=5'b00010;4:font5x7=5'b00100;5:font5x7=5'b01000;default:font5x7=5'b11111;endcase
   3:case(row)0:font5x7=5'b11110;1:font5x7=5'b00001;2:font5x7=5'b00001;3:font5x7=5'b01110;4:font5x7=5'b00001;5:font5x7=5'b00001;default:font5x7=5'b11110;endcase
   4:case(row)0:font5x7=5'b00010;1:font5x7=5'b00110;2:font5x7=5'b01010;3:font5x7=5'b10010;4:font5x7=5'b11111;5:font5x7=5'b00010;default:font5x7=5'b00010;endcase
   5:case(row)0:font5x7=5'b11111;1:font5x7=5'b10000;2:font5x7=5'b10000;3:font5x7=5'b11110;4:font5x7=5'b00001;5:font5x7=5'b00001;default:font5x7=5'b11110;endcase
   6:case(row)0:font5x7=5'b00110;1:font5x7=5'b01000;2:font5x7=5'b10000;3:font5x7=5'b11110;4:font5x7=5'b10001;5:font5x7=5'b10001;default:font5x7=5'b01110;endcase
   7:case(row)0:font5x7=5'b11111;1:font5x7=5'b00001;2:font5x7=5'b00010;3:font5x7=5'b00100;4:font5x7=5'b01000;5:font5x7=5'b01000;default:font5x7=5'b01000;endcase
   8:case(row)0:font5x7=5'b01110;1:font5x7=5'b10001;2:font5x7=5'b10001;3:font5x7=5'b01110;4:font5x7=5'b10001;5:font5x7=5'b10001;default:font5x7=5'b01110;endcase
   9:case(row)0:font5x7=5'b01110;1:font5x7=5'b10001;2:font5x7=5'b10001;3:font5x7=5'b01111;4:font5x7=5'b00001;5:font5x7=5'b00010;default:font5x7=5'b11100;endcase
   default:case(row)0,6:font5x7=0;1:font5x7=5'b10001;2:font5x7=5'b01010;3:font5x7=5'b00100;4:font5x7=5'b01010;5:font5x7=5'b10001;default:font5x7=0;endcase
  endcase end
 endfunction

 reg [9:0] x,y; reg vs_d; reg glyph;
 reg [3:0] char_no,digit; reg [3:0] col; reg [2:0] row;
 reg [4:0] bits;
 always @* begin
  glyph=0;char_no=0;digit=15;col=0;row=0;bits=0;
  if(x>=12&&x<120&&y>=12&&y<26) begin
   char_no=(x-12)/12; col=((x-12)%12)>>1; row=(y-12)>>1;
   case(char_no)
    0: digit=(src_w>=1000)?(src_w/1000):15;
    1: digit=(src_w/100)%10;
    2: digit=(src_w/10)%10;
    3: digit=src_w%10;
    4: digit=10;
    5: digit=(src_h>=1000)?(src_h/1000):15;
    6: digit=(src_h/100)%10;
    7: digit=(src_h/10)%10;
    default:digit=src_h%10;
   endcase
   if(digit<=10&&col<5)begin bits=font5x7(digit,row);glyph=bits[4-col];end
  end
 end

 always @(posedge clk or posedge rst) begin
  if(rst)begin x<=0;y<=0;vs_d<=0;vs_out<=0;de_out<=0;rgb_out<=0;end
  else begin
   vs_d<=vs_in;
   if(vs_in&&!vs_d)begin x<=0;y<=0;end
   else if(de_in)begin if(x==639)begin x<=0;if(y<479)y<=y+1'b1;end else x<=x+1'b1;end
   vs_out<=vs_in;de_out<=de_in;
   if(enable&&de_in&&x>=4&&x<132&&y>=4&&y<34) rgb_out<=glyph?24'hFFFFFF:24'h102038;
   else rgb_out<=rgb_in;
  end
 end
endmodule

