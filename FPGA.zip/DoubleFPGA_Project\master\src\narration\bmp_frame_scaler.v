// Streaming nearest-neighbour scaler for 24-bit BMP pixels.
// Two 2048-pixel line buffers preserve pixels that follow a row boundary in
// the same 512-byte SD sector. The output is always exactly 640x480.
module bmp_frame_scaler(
 input clk,input rst,input scale_enable,input [2:0] scale_level,
 input [11:0] source_width,input [11:0] source_height,
 input write_req,input write_req_ack,input downstream_ready,
 input source_we,input [23:0] source_data,
 output source_sector_ready,output reg out_we,output reg [23:0] out_data);
 localparam S_WAIT=0,S_CAPTURE=1,S_VCALC=2,S_ADDR=3,S_PIXEL=4,S_DONE=5;
 reg [2:0] state;reg ack_d,wr_sel,pending_sel,last_line;
 reg [11:0] src_w,src_h,captured_y;reg [10:0] src_last_x,in_x,rd_x;
 reg [9:0] out_x;reg [11:0] h_acc,v_acc,v_work;reg [9:0] emit_rows;
 reg [2:0] write_pace;
 wire frame_start=write_req_ack&&!ack_d;
 wire line0_we=source_we&&!wr_sel;wire line1_we=source_we&&wr_sel;
 wire [23:0] line0_q,line1_q;wire [23:0] line_q=pending_sel?line1_q:line0_q;
 wire [12:0] h_sum={1'b0,h_acc}+{1'b0,src_w};
 wire source_line_end=source_we&&(in_x==src_last_x);
 assign source_sector_ready=(state==S_CAPTURE);
 ram_infer_wfifo_32_32_512 #(
  .MODE("SDP"),.DATAWIDTH_A(24),.ADDRWIDTH_A(11),.DATADEPTH_A(2048),
  .DATAWIDTH_B(24),.ADDRWIDTH_B(11),.DATADEPTH_B(2048),
  .REGMODE_A("NOREG"),.REGMODE_B("NOREG")) u_scale_line0(
  .clka(clk),.rsta(rst),.cea(1'b1),.ocea(1'b1),.wea(line0_we),.dia(source_data),.addra(in_x),.doa(),
  .clkb(clk),.rstb(rst),.ceb(1'b1),.oceb(1'b1),.web(1'b0),.dib(24'b0),.addrb(rd_x),.dob(line0_q));
 ram_infer_wfifo_32_32_512 #(
  .MODE("SDP"),.DATAWIDTH_A(24),.ADDRWIDTH_A(11),.DATADEPTH_A(2048),
  .DATAWIDTH_B(24),.ADDRWIDTH_B(11),.DATADEPTH_B(2048),
  .REGMODE_A("NOREG"),.REGMODE_B("NOREG")) u_scale_line1(
  .clka(clk),.rsta(rst),.cea(1'b1),.ocea(1'b1),.wea(line1_we),.dia(source_data),.addra(in_x),.doa(),
  .clkb(clk),.rstb(rst),.ceb(1'b1),.oceb(1'b1),.web(1'b0),.dib(24'b0),.addrb(rd_x),.dob(line1_q));
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   state<=S_WAIT;ack_d<=0;wr_sel<=0;pending_sel<=0;last_line<=0;src_w<=640;src_h<=480;src_last_x<=639;
   captured_y<=0;in_x<=0;rd_x<=0;out_x<=0;h_acc<=0;v_acc<=0;v_work<=0;
   emit_rows<=0;write_pace<=0;out_we<=0;out_data<=0;
  end else begin
   ack_d<=write_req_ack;out_we<=0;
   if(frame_start)begin
    state<=S_CAPTURE;wr_sel<=0;pending_sel<=0;last_line<=0;src_w<=source_width;src_h<=source_height;
    src_last_x<=source_width-1'b1;
    captured_y<=0;in_x<=0;rd_x<=0;out_x<=0;h_acc<=0;v_acc<=0;v_work<=0;emit_rows<=0;write_pace<=0;
   end else begin
    if(write_pace!=0)write_pace<=write_pace-1'b1;
    // The SD transport completes its current sector even after ready drops.
    // Continue writing those trailing pixels into the alternate line buffer.
    if(source_we)begin
     if(source_line_end)begin
      in_x<=0;pending_sel<=wr_sel;wr_sel<=~wr_sel;last_line<=(captured_y+1'b1>=src_h);
      captured_y<=captured_y+1'b1;v_work<=v_acc+12'd480;emit_rows<=0;state<=S_VCALC;
     end else in_x<=in_x+1'b1;
    end
    if(!source_line_end)case(state)
     S_VCALC:if(v_work>=src_h)begin v_work<=v_work-src_h;emit_rows<=emit_rows+1'b1;end
     else begin
      v_acc<=v_work;
      if(emit_rows==0)state<=last_line?S_DONE:S_CAPTURE;
      else begin rd_x<=0;out_x<=0;h_acc<=0;state<=S_ADDR;end
     end
     S_ADDR:state<=S_PIXEL;
    // Limit scaler writes to about 33 Mpixel/s. Together with the mandatory
    // BRAM address cycle this stays below the old unsafe 50 Mpixel/s burst,
    // while cutting a cache-miss frame build to about 0.9 s.
     S_PIXEL:if(downstream_ready&&write_pace==0)begin
      out_we<=1;out_data<=line_q;write_pace<=3'd2;
      if(out_x==10'd639)begin
       if(emit_rows>1)begin emit_rows<=emit_rows-1'b1;rd_x<=0;out_x<=0;h_acc<=0;state<=S_ADDR;end
       else state<=last_line?S_DONE:S_CAPTURE;
      end else begin
       out_x<=out_x+1'b1;
       if(h_sum>=13'd1920)begin h_acc<=h_sum-13'd1920;rd_x<=rd_x+3'd3;end
       else if(h_sum>=13'd1280)begin h_acc<=h_sum-13'd1280;rd_x<=rd_x+2'd2;end
       else if(h_sum>=13'd640)begin h_acc<=h_sum-13'd640;rd_x<=rd_x+1'b1;end
       else h_acc<=h_sum[11:0];
       state<=S_ADDR;
      end
     end
     default:;
    endcase
   end
  end
 end
endmodule
