// Exact caption is a 15-cell, 32x32 font strip. Frame-synchronous x increases:
// left edge = scroll_position - 480, therefore motion is LEFT TO RIGHT.
module cover_scroll_osd(
    input clk,rst,vs_in,de_in,
    input [23:0] rgb_in,
    input display_valid,
    input [5:0] fade_gain,
    input [3:0] display_image,
    output reg vs_out,de_out,
    output reg [23:0] rgb_out
);
reg de_last,vs_last;
reg [9:0] x,y;
reg [10:0] scroll_position;
reg cover_last;
wire cover_active=display_valid && display_image==0;
wire [10:0] strip_x={1'b0,x}+11'd480-scroll_position;
wire text_area=cover_active && de_in && y>=444 && y<476 && strip_x<480;
wire band=cover_active && de_in && y>=440;
wire [8:0] font_address={strip_x[8:5],y[4:0]-5'd28};
wire [31:0] glyph_row;
reg [4:0] glyph_column;
reg text_q,band_q,valid_q,vs_q,de_q;
reg [23:0] rgb_q;
function [23:0] fade_rgb;
    input [23:0] color;
    input [5:0] gain;
    reg [13:0] r,g,b;
    begin
        r=color[23:16]*gain; g=color[15:8]*gain; b=color[7:0]*gain;
        fade_rgb={r[12:5],g[12:5],b[12:5]};
    end
endfunction
caption_font_rom u_caption_font(.clk(clk),.address(font_address),.data(glyph_row));
always @(posedge clk or posedge rst) begin
    if(rst) begin
        de_last<=0;vs_last<=0;x<=0;y<=0;scroll_position<=0;cover_last<=0;
        glyph_column<=0;text_q<=0;band_q<=0;valid_q<=0;vs_q<=0;de_q<=0;rgb_q<=0;
        vs_out<=0;de_out<=0;rgb_out<=0;
    end else begin
        de_last<=de_in;vs_last<=vs_in;cover_last<=cover_active;
        if(!de_in) x<=0; else x<=x+1'b1;
        if(vs_last && !vs_in) y<=0;
        else if(de_last && !de_in) y<=y+1'b1;
        if(!cover_active || !cover_last) scroll_position<=0;
        else if(vs_last && !vs_in)
            scroll_position <= (scroll_position>=1120) ? 0 : scroll_position+11'd2;
        glyph_column<=strip_x[4:0]; text_q<=text_area;band_q<=band;
        valid_q<=display_valid;vs_q<=vs_in;de_q<=de_in;rgb_q<=rgb_in;
        vs_out<=vs_q;de_out<=de_q;
        if(!valid_q || !de_q) rgb_out<=0;
        else if(text_q && glyph_row[31-glyph_column]) rgb_out<=fade_rgb(24'hffe080,fade_gain);
        else if(band_q) rgb_out<=fade_rgb(24'h081a2e,fade_gain);
        else rgb_out<=fade_rgb(rgb_q,fade_gain);
    end
end
endmodule
