import_device eagle_s20.db -package EG4S20BG256
open_project ./DoubleFPGA_Slave.al
set_param place effort high -run phy_1
set_param place opt_timing high -run phy_1
set_param place post_place_opt on -run phy_1
set_param route effort high -run phy_1
set_param route fix_hold on -run phy_1
reset_runs phy_1
launch_runs phy_1 -jobs 1
wait_run phy_1
save_best_bits
close_project
exit
