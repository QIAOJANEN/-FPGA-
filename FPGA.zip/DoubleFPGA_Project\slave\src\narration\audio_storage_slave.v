// Audio-only FAT32 reader for the slave SD card.  Expected files are
// BGM.PCM and N00.PCM..N13.PCM, raw 48 kHz stereo PCM16 little-endian.
module audio_storage_slave(
 input clk,input audio_mclk,input rst,input narration_enable,input [3:0] image_index,input command_toggle,input bgm_enable,
 output [23:0] audio_left,audio_right,output audio_toggle,output audio_busy,
 output SD_nCS,SD_DCLK,SD_MOSI,input SD_MISO,output [3:0] state_code);
 wire sd_init_done,sec_read,sec_valid,sec_end;wire [31:0] sec_address;wire [7:0] sec_data;
 wire bgm_req,bgm_valid,bgm_end;wire [31:0] bgm_addr;wire [7:0] bgm_data;
 wire nar_req,nar_valid,nar_end;wire [31:0] nar_addr;wire [7:0] nar_data;
 wire bgm_we,bgm_full,bgm_empty,bgm_rd,bgm_dvalid,bgm_error,bgm_pulse;wire [31:0] bgm_din,bgm_dout;wire [9:0] bgm_used;wire [3:0] bgm_state;wire [23:0] bgm_l,bgm_r;
 wire nar_we,nar_full,nar_empty,nar_rd,nar_dvalid,nar_error,nar_pulse,nar_playing,nar_flush_toggle;wire [31:0] nar_din,nar_dout;wire [9:0] nar_used;wire [3:0] nar_state;wire [23:0] nar_l,nar_r;
 reg [3:0] last_image;reg last_enable;reg play_toggle;reg flush_seen;reg [7:0] reset_count;reg nar_prefilled;
 reg cmd_m,cmd_s,cmd_seen;reg en_m,en_s;reg [3:0] img_m,img_s;
 reg nar_active_m,nar_active_a,bgm_en_m,bgm_en_a;wire [23:0] mixed_left,mixed_right;
 wire fifo_reset_busy=(reset_count!=0);wire nar_fifo_rst=rst|fifo_reset_busy;
 assign state_code=nar_error?4'hb:bgm_error?4'hc:(nar_state!=0?nar_state:bgm_state);
 assign audio_busy=en_s&&(nar_playing||nar_prefilled||(nar_used!=0)||fifo_reset_busy);
 always @(posedge clk or posedge rst) begin
  if(rst) begin last_image<=0;last_enable<=0;play_toggle<=0;flush_seen<=0;reset_count<=0;nar_prefilled<=0;cmd_m<=0;cmd_s<=0;cmd_seen<=0;en_m<=0;en_s<=0;img_m<=0;img_s<=0;end
  else begin
   cmd_m<=command_toggle;cmd_s<=cmd_m;en_m<=narration_enable;en_s<=en_m;img_m<=image_index;img_s<=img_m;
   if(cmd_s!=cmd_seen) begin
    cmd_seen<=cmd_s;
    if(en_s && (!last_enable || img_s!=last_image)) play_toggle<=~play_toggle;
    last_image<=img_s;last_enable<=en_s;
   end
   if(nar_flush_toggle!=flush_seen) begin flush_seen<=nar_flush_toggle;reset_count<=8'd63;nar_prefilled<=0;end
   else begin
    if(reset_count!=0) reset_count<=reset_count-1'b1;
    if(!en_s) nar_prefilled<=0;
    else if(!nar_prefilled && ((nar_playing&&nar_used>=10'd768)||(!nar_playing&&nar_used!=0))) nar_prefilled<=1;
    else if(nar_prefilled&&!nar_playing&&nar_used==0) nar_prefilled<=0;
   end
  end
 end
 always @(posedge audio_mclk or posedge rst) begin
  if(rst)begin nar_active_m<=0;nar_active_a<=0;bgm_en_m<=0;bgm_en_a<=0;end
  else begin nar_active_m<=nar_prefilled;nar_active_a<=nar_active_m;bgm_en_m<=bgm_enable;bgm_en_a<=bgm_en_m;end
 end
 audio_fat_stream #(.FIFO_AW(10)) u_bgm(.clk(clk),.rst(rst),.sd_init_done(sd_init_done),.sec_req(bgm_req),.sec_addr(bgm_addr),.sec_data(bgm_data),.sec_valid(bgm_valid),.sec_end(bgm_end),
  .fifo_we(bgm_we),.fifo_din(bgm_din),.fifo_full(bgm_full),.fifo_used({1'b0,bgm_used}),.ready(),.error(bgm_error),.state_code(bgm_state));
 narration_fat_stream #(.FIFO_AW(10)) u_nar(.clk(clk),.rst(rst),.sd_init_done(sd_init_done),.enable(en_s),.file_index(last_image),.play_toggle(play_toggle),.fifo_reset_busy(fifo_reset_busy),
  .sec_req(nar_req),.sec_addr(nar_addr),.sec_data(nar_data),.sec_valid(nar_valid),.sec_end(nar_end),.fifo_we(nar_we),.fifo_din(nar_din),.fifo_full(nar_full),.fifo_used({1'b0,nar_used}),
  .catalog_ready(),.playing(nar_playing),.error(nar_error),.flush_toggle(nar_flush_toggle),.state_code(nar_state));
 sd_read_arbiter3 u_arb(.clk(clk),.rst(rst),.bmp_req(1'b0),.bmp_addr(32'd0),.bmp_valid(),.bmp_data(),.bmp_end(),
  .bgm_req(bgm_req),.bgm_addr(bgm_addr),.bgm_valid(bgm_valid),.bgm_data(bgm_data),.bgm_end(bgm_end),.nar_req(nar_req),.nar_addr(nar_addr),.nar_valid(nar_valid),.nar_data(nar_data),.nar_end(nar_end),
  .sd_req(sec_read),.sd_addr(sec_address),.sd_valid(sec_valid),.sd_data(sec_data),.sd_end(sec_end));
 sd_card_top u_sd(.clk(clk),.rst(rst),.SD_nCS(SD_nCS),.SD_DCLK(SD_DCLK),.SD_MOSI(SD_MOSI),.SD_MISO(SD_MISO),.sd_init_done(sd_init_done),.sd_sec_read(sec_read),
  .sd_sec_read_addr(sec_address),.sd_sec_read_data(sec_data),.sd_sec_read_data_valid(sec_valid),.sd_sec_read_end(sec_end),.sd_sec_write(1'b0),.sd_sec_write_addr(32'd0),.sd_sec_write_data(),.sd_sec_write_data_req(),.sd_sec_write_end());
 wfifo_32_32_512 #(.ADDR_WIDTH_W(10),.ADDR_WIDTH_R(10),.AL_FULL_NUM(1021),.AL_EMPTY_NUM(2)) u_bgm_fifo(.clkw(clk),.clkr(audio_mclk),.rst(rst),.we(bgm_we),.di(bgm_din),.full_flag(bgm_full),.re(bgm_rd),.dout(bgm_dout),.empty_flag(bgm_empty),.valid(bgm_dvalid),.wrusedw(bgm_used),.afull(),.aempty(),.rdusedw());
 wfifo_32_32_512 #(.ADDR_WIDTH_W(10),.ADDR_WIDTH_R(10),.AL_FULL_NUM(1021),.AL_EMPTY_NUM(2)) u_nar_fifo(.clkw(clk),.clkr(audio_mclk),.rst(nar_fifo_rst),.we(nar_we),.di(nar_din),.full_flag(nar_full),.re(nar_rd),.dout(nar_dout),.empty_flag(nar_empty),.valid(nar_dvalid),.wrusedw(nar_used),.afull(),.aempty(),.rdusedw());
 pcm_audio_player u_bp(.mclk(audio_mclk),.rst(rst),.fifo_empty(bgm_empty),.fifo_rd(bgm_rd),.fifo_data(bgm_dout),.fifo_valid(bgm_dvalid),.sample_toggle(),.left_sample(bgm_l),.right_sample(bgm_r),.sample_pulse(bgm_pulse));
 pcm_audio_player u_np(.mclk(audio_mclk),.rst(nar_fifo_rst),.fifo_empty(nar_empty||!nar_active_a),.fifo_rd(nar_rd),.fifo_data(nar_dout),.fifo_valid(nar_dvalid),.sample_toggle(),.left_sample(nar_l),.right_sample(nar_r),.sample_pulse(nar_pulse));
 audio_mix_duck u_mix(.clk(audio_mclk),.rst(rst),.bgm_enable(bgm_en_a),.bgm_pulse(bgm_pulse),.bgm_left(bgm_l),.bgm_right(bgm_r),.nar_left(nar_l),.nar_right(nar_r),.narration_playing(nar_active_a),.sample_toggle(audio_toggle),.sample_pulse(),.left_sample(audio_left),.right_sample(audio_right));
endmodule
