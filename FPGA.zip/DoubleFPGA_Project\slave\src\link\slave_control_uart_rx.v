module slave_control_uart_rx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 1_000_000
)(
    input wire clk,input wire rst,input wire rx,
    output reg narration_enable,output reg [3:0] image_index,output reg command_toggle
);
    localparam integer DIV=CLK_HZ/BAUD;
    reg rx_m,rx_s,rx_d,busy; reg [15:0] count; reg [3:0] bit_index; reg [7:0] payload;
    always @(posedge clk or posedge rst) begin
        if(rst) begin rx_m<=1;rx_s<=1;rx_d<=1;busy<=0;count<=0;bit_index<=0;payload<=0;narration_enable<=0;image_index<=0;command_toggle<=0;end
        else begin
            rx_m<=rx;rx_s<=rx_m;rx_d<=rx_s;
            if(!busy) begin
                if(rx_d && !rx_s) begin busy<=1;count<=DIV+(DIV/2)-1;bit_index<=0;end
            end else if(count!=0) count<=count-1'b1;
            else if(bit_index<8) begin payload[bit_index]<=rx_s;bit_index<=bit_index+1'b1;count<=DIV-1;end
            else begin
                busy<=0;
                if(rx_s && payload[7:6]==2'b11 && payload[0]==^(payload[7:1])) begin
                    // The master refreshes the packet every millisecond.  Only
                    // publish a command event when its semantic value changes;
                    // otherwise a repeated packet can race the separately
                    // synchronized image bus at a manual-change boundary.
                    if(payload[5]!=narration_enable || payload[4:1]!=image_index)
                        command_toggle<=~command_toggle;
                    narration_enable<=payload[5];image_index<=payload[4:1];
                end
            end
        end
    end
endmodule
