// Two SDRAM buffers, fourteen files. Payload stays stable until swap acknowledgement.
module playlist14 #(
    parameter integer CLK_HZ = 100000000,
    parameter integer COVER_SECONDS = 12,
    parameter integer IMAGE_SECONDS = 5
)(
    input clk, rst, catalog_ready, source_done, source_error,
    input write_finish_toggle, next_press, auto_press,
    input swap_ack_toggle,
    output reg load_start,
    output reg [3:0] load_index,
    output reg [1:0] write_buf_idx,
    output reg swap_toggle,
    output reg [1:0] swap_buffer,
    output reg [3:0] swap_image,
    output reg auto_enabled,
    output reg [3:0] current_image,
    output reg display_started,
    output wire fault
);
localparam BOOT=0, LOADING=1, READY=2, SWAPPING=3, FAILED=4;
reg [2:0] state;
reg [2:0] finish_sync, ack_sync;
reg source_seen, finish_seen, next_pending;
reg [31:0] seconds_div;
reg [3:0] seconds_count;
wire finished = finish_sync[2] ^ finish_sync[1];
wire auto_due = auto_enabled && !auto_press && display_started &&
                (seconds_count >= ((current_image == 0) ? COVER_SECONDS : IMAGE_SECONDS));
assign fault = state == FAILED;
always @(posedge clk or posedge rst) begin
    if (rst) begin
        state<=BOOT; finish_sync<=0; ack_sync<=0;
        source_seen<=0; finish_seen<=0; next_pending<=0;
        seconds_div<=0; seconds_count<=0;
        load_start<=0; load_index<=0; write_buf_idx<=0;
        swap_toggle<=0; swap_buffer<=0; swap_image<=0;
        auto_enabled<=0; current_image<=0; display_started<=0;
    end else begin
        finish_sync <= {finish_sync[1:0],write_finish_toggle};
        ack_sync <= {ack_sync[1:0],swap_ack_toggle};
        load_start <= 0;
        if (auto_press) begin
            auto_enabled <= ~auto_enabled;
            seconds_div<=0; seconds_count<=0;
        end else if (auto_enabled && display_started && !auto_due) begin
            if (seconds_div == CLK_HZ-1) begin
                seconds_div<=0; seconds_count<=seconds_count+1'b1;
            end else seconds_div<=seconds_div+1'b1;
        end
        // A press during prefetch is remembered; repeated presses coalesce to one.
        if (next_press) next_pending<=1;
        case (state)
        BOOT: if (catalog_ready) begin
            load_index<=0; write_buf_idx<=0; load_start<=1;
            source_seen<=0; finish_seen<=0; state<=LOADING;
        end
        LOADING: begin
            if (source_done) source_seen<=1;
            if (finished) finish_seen<=1;
            if (source_error) state<=FAILED;
            else if ((source_seen || source_done) && (finish_seen || finished)) state<=READY;
        end
        READY: if (!display_started || next_pending || next_press || auto_due) begin
            swap_buffer<=write_buf_idx;
            swap_image<=load_index;
            swap_toggle<=~swap_toggle;
            // The initial cover commit must not consume a press queued while
            // the first image was loading. That press advances AFTER the cover.
            if (display_started) next_pending<=0;
            state<=SWAPPING;
        end
        SWAPPING: if (ack_sync[2] == swap_toggle) begin
            current_image<=load_index;
            display_started<=1;
            seconds_div<=0; seconds_count<=0;
            // The video reader has acknowledged its NEW buffer. Only now reuse old one.
            write_buf_idx<={1'b0,~write_buf_idx[0]};
            load_index<=(load_index==13) ? 0 : load_index+1'b1;
            load_start<=1; source_seen<=0; finish_seen<=0;
            state<=LOADING;
        end
        FAILED: ; // Keep last committed picture, require K1 after correcting the card.
        default: state<=BOOT;
        endcase
    end
end
endmodule
