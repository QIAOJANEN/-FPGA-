module sd_card_bmp #(parameter integer CLK_FREQ_HZ=100000000)(
    input clk, rst, key_next, key_auto,
    output [3:0] state_code,
    input write_finish_toggle, write_sector_ready,
    input swap_ack_toggle,
    output swap_toggle,
    output [1:0] swap_buffer,
    output [3:0] swap_image,
    output [1:0] write_buf_idx,
    output write_req,
    input write_req_ack,
    output write_en,
    output [31:0] write_data,
    output SD_nCS, SD_DCLK, SD_MOSI,
    input SD_MISO
);
wire next_press, auto_press, sd_init_done;
wire sec_read, sec_valid, sec_end;
wire [31:0] sec_address;
wire [7:0] sec_data;
wire catalog_ready, load_start, load_done, reader_error, playlist_error;
wire [3:0] load_index, reader_state;
wire [23:0] rgb;
assign write_data={rgb,8'b0};
assign state_code=playlist_error && !reader_error ? 4'hf : reader_state;
key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ)) u_key_next(
    .clk(clk),.rst(rst),.button_in(key_next),.press_pulse(next_press));
key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ)) u_key_auto(
    .clk(clk),.rst(rst),.button_in(key_auto),.press_pulse(auto_press));
playlist14 #(.CLK_HZ(CLK_FREQ_HZ)) u_playlist(
    .clk(clk),.rst(rst),.catalog_ready(catalog_ready),.source_done(load_done),
    .source_error(reader_error),.write_finish_toggle(write_finish_toggle),
    .next_press(next_press),.auto_press(auto_press),.swap_ack_toggle(swap_ack_toggle),
    .load_start(load_start),.load_index(load_index),.write_buf_idx(write_buf_idx),
    .swap_toggle(swap_toggle),.swap_buffer(swap_buffer),.swap_image(swap_image),
    .auto_enabled(),.current_image(),.display_started(),.fault(playlist_error));
bmp_read bmp_read_m0(
    .clk(clk),.rst(rst),.sd_init_done(sd_init_done),.catalog_ready(catalog_ready),.found_mask(),
    .load_start(load_start),.load_index(load_index),.load_done(load_done),.error(reader_error),
    .state_code(reader_state),.write_req(write_req),.write_req_ack(write_req_ack),
    .write_sector_ready(write_sector_ready),.sd_sec_read(sec_read),.sd_sec_read_addr(sec_address),
    .sd_sec_read_data(sec_data),.sd_sec_read_data_valid(sec_valid),.sd_sec_read_end(sec_end),
    .bmp_data_wr_en(write_en),.bmp_data(rgb));
sd_card_top sd_card_top_m0(
    .clk(clk),.rst(rst),.SD_nCS(SD_nCS),.SD_DCLK(SD_DCLK),.SD_MOSI(SD_MOSI),.SD_MISO(SD_MISO),
    .sd_init_done(sd_init_done),.sd_sec_read(sec_read),.sd_sec_read_addr(sec_address),
    .sd_sec_read_data(sec_data),.sd_sec_read_data_valid(sec_valid),.sd_sec_read_end(sec_end),
    .sd_sec_write(1'b0),.sd_sec_write_addr(32'd0),.sd_sec_write_data(),
    .sd_sec_write_data_req(),.sd_sec_write_end());
endmodule

module key_press_debounce #(
    parameter integer CLK_FREQ_HZ=100000000,
    parameter integer DEBOUNCE_MS=20
)(input clk,rst,button_in,output reg press_pulse);
localparam integer CYCLES=(CLK_FREQ_HZ/1000)*DEBOUNCE_MS;
reg meta,sync_button,stable;
reg [31:0] count;
always @(posedge clk or posedge rst) begin
    if(rst) begin meta<=1;sync_button<=1;stable<=1;count<=0;press_pulse<=0; end
    else begin
        meta<=button_in;sync_button<=meta;press_pulse<=0;
        if(sync_button==stable) count<=0;
        else if(count>=CYCLES-1) begin
            press_pulse<=stable && !sync_button;stable<=sync_button;count<=0;
        end else count<=count+1'b1;
    end
end
endmodule
