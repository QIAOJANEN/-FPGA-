# DoubleFPGA build report

Built with Tang Dynasty 6.2.168116 for EG4S20BG256. Both boards were rebuilt from the submitted sources on 2026-10-23.

| Image | Size | SHA-256 | Setup WNS | Hold WNS |
|---|---:|---|---:|---:|
| `DoubleFPGA_Master.bit` | 690152 bytes | `295DFBBD3382326716FBB99FE604100652E760C2F2E5CDBD56D8224FCEFF5A9B` | +108 ps | +12 ps |
| `DoubleFPGA_Slave.bit` | 629624 bytes | `1FF52B4281CA662E4E6058296A9A42691E58D1DF86DA4FC82B2417FF22EB9E9B` | +136 ps | +16 ps |

Both place-and-route runs completed with zero setup and hold failing endpoints. The master's inherited SDRAM local-clock critical warning remains, but no abnormal timing path or new link-related critical warning is present.

The matched pair implements:

- Four tagged SDRAM frame buffers, current-frame protection and adjacent-image background prefetch.
- Hardware parsing and nearest-neighbour scaling of positive-height, uncompressed 24-bit BMP files to 640×480.
- Atomic image, caption, display-number and narration commits at a completed frame swap.
- Fade, horizontal-curtain and vertical-blinds transitions in the same 1-2-3 cycle for manual and automatic playback.
- Automatic advance only after the minimum dwell and the returned narration busy flag are both complete.
- Complete transcript captions with punctuation rendered as spaces and a corrected glyph/video pipeline.
- Master KEY1 full logical reset and active-low SW4 whole-system run control.
- Slave SW1 control of the HDMI RGB spectrum columns and slave SW2 control of background music only.
- A 1 Mbaud master-to-slave command UART, 115200 baud slave-to-master status UART and 64 fs I2S audio return.

The reverse status frame is `0xA0 | {bgm_enable, spectrum_enable, audio_busy}`. The asynchronous narration busy level is synchronized through two flip-flops before transmission; the master receiver also applies a watchdog-safe default. The verification testbench covers the forward command and reverse status fields.

Narration files `N00.PCM` through `N13.PCM` are clean offline 1.2× resamples stored on the slave SD card. The FPGA plays standard 48 kHz, stereo, signed 16-bit little-endian PCM without real-time sample skipping. The cover minimum dwell is about 8 seconds and the remaining images use about 7 seconds; narration busy remains the final automatic-advance condition.

Use the master bitstream only on the HDMI/image-SD board and the slave bitstream only on the audio-SD board. Both boards must be programmed from this same build and connected according to `README.md`.
