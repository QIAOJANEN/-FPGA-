module sd_read_arbiter(
 input clk,rst,
 input bmp_req,input [31:0] bmp_addr,output bmp_valid,output [7:0] bmp_data,output bmp_end,
 input aud_req,input [31:0] aud_addr,output aud_valid,output [7:0] aud_data,output aud_end,
 output sd_req,output [31:0] sd_addr,input sd_valid,input [7:0] sd_data,input sd_end);
 reg active,owner,drain; reg [31:0] address;
 assign sd_req=active; assign sd_addr=address;
 assign bmp_valid=sd_valid&&active&&!owner;assign bmp_end=sd_end&&active&&!owner;assign bmp_data=sd_data;
 assign aud_valid=sd_valid&&active&&owner;assign aud_end=sd_end&&active&&owner;assign aud_data=sd_data;
 always @(posedge clk or posedge rst) begin
  if(rst) begin active<=0;owner<=0;drain<=0;address<=0;end else begin
   if(active&&sd_end) begin active<=0;drain<=1;end
   // The completed owner must release its level request before a new
   // transfer starts. The other client may already be queued.
   else if(drain) begin
    if((owner&&!aud_req)||(!owner&&!bmp_req)) drain<=0;
   end
   else if(!active) begin
    if(aud_req) begin active<=1;owner<=1;address<=aud_addr;end
    else if(bmp_req) begin active<=1;owner<=0;address<=bmp_addr;end
   end
  end
 end
endmodule
