module sd_card_multimedia #(parameter integer CLK_FREQ_HZ=100000000)(
 input clk,audio_mclk,rst,key_next,key_auto,key_prev,
 input narration_enable,input [3:0] narration_image,input narration_play_toggle,
 input scale_enable,input [2:0] scale_level,input scale_change_toggle,
 output [3:0] state_code,input write_finish_toggle,write_sector_ready,swap_ack_toggle,
 output swap_toggle,output [1:0] swap_buffer,output [3:0] swap_image,output [1:0] write_buf_idx,
 output write_req,input write_req_ack,output write_en,output [31:0] write_data,
 output audio_toggle,output [23:0] audio_left,audio_right,output [111:0] spectrum_levels,
 output SD_nCS,SD_DCLK,SD_MOSI,input SD_MISO);
 wire next_press,auto_press,prev_press,sd_init_done,sec_read,sec_valid,sec_end; wire [31:0] sec_address;wire [7:0] sec_data;
 wire bmp_req,bmp_valid,bmp_end;wire [31:0] bmp_addr;wire [7:0] bmp_data;
 wire bgm_req,bgm_valid,bgm_end;wire [31:0] bgm_addr;wire [7:0] bgm_data;
 wire nar_req,nar_valid,nar_end;wire [31:0] nar_addr;wire [7:0] nar_data;
 wire catalog_ready,load_start,load_done,reader_error,playlist_error;wire [3:0] load_index,reader_state;
 wire [23:0] rgb,raw_rgb;wire raw_write_en,source_sector_ready;
 assign write_data={rgb,8'b0};
 wire bgm_we,bgm_full,bgm_empty,bgm_rd,bgm_dvalid,bgm_error,bgm_pulse;wire [31:0] bgm_din,bgm_dout;wire [9:0] bgm_used;wire [3:0] bgm_state;wire bgm_toggle;wire [23:0] bgm_l,bgm_r;
 wire nar_we,nar_full,nar_empty,nar_rd,nar_dvalid,nar_error,nar_pulse,nar_playing,nar_flush_toggle;wire [31:0] nar_din,nar_dout;wire [9:0] nar_used;wire [3:0] nar_state;wire nar_toggle;wire [23:0] nar_l,nar_r;
 reg nar_flush_seen;reg [7:0] nar_reset_count;wire nar_fifo_reset_busy=(nar_reset_count!=0);wire nar_fifo_rst=rst|nar_fifo_reset_busy;
 reg nar_en_m,nar_en_s,nar_tog_m,nar_tog_s;reg [3:0] nar_img_m,nar_img_s;
 reg nar_prefilled_sd,nar_active_m,nar_active_a;
 always @(posedge clk or posedge rst)begin
  if(rst)begin nar_en_m<=0;nar_en_s<=0;nar_tog_m<=0;nar_tog_s<=0;nar_img_m<=0;nar_img_s<=0;nar_flush_seen<=0;nar_reset_count<=0;nar_prefilled_sd<=0;end
  else begin nar_en_m<=narration_enable;nar_en_s<=nar_en_m;nar_tog_m<=narration_play_toggle;nar_tog_s<=nar_tog_m;nar_img_m<=narration_image;nar_img_s<=nar_img_m;
   if(nar_flush_toggle!=nar_flush_seen)begin nar_flush_seen<=nar_flush_toggle;nar_reset_count<=8'd63;nar_prefilled_sd<=0;end
   else begin
    if(nar_reset_count!=0)nar_reset_count<=nar_reset_count-1'b1;
    // Start after a healthy prefill, then keep the player active until the
    // reader has reached EOF and every buffered sample has been consumed.
    if(!nar_en_s)nar_prefilled_sd<=0;
    else if(!nar_prefilled_sd && ((nar_playing&&nar_used>=10'd768)||(!nar_playing&&nar_used!=0)))nar_prefilled_sd<=1;
    else if(nar_prefilled_sd&&!nar_playing&&(nar_used==0))nar_prefilled_sd<=0;
   end
  end
 end
 always @(posedge audio_mclk or posedge rst)begin if(rst)begin nar_active_m<=0;nar_active_a<=0;end else begin nar_active_m<=nar_prefilled_sd;nar_active_a<=nar_active_m;end end
 assign state_code=reader_error?reader_state:playlist_error?4'hf:nar_error?4'hb:bgm_error?4'hc:reader_state;
 key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(10)) u_kn(.clk(clk),.rst(rst),.button_in(key_next),.press_pulse(next_press));
 key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(10)) u_ka(.clk(clk),.rst(rst),.button_in(key_auto),.press_pulse(auto_press));
 key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(10)) u_kp(.clk(clk),.rst(rst),.button_in(key_prev),.press_pulse(prev_press));
 wire narration_busy=nar_en_s&&(nar_playing||nar_prefilled_sd||(nar_used!=0)||nar_fifo_reset_busy);
 playlist14 #(.CLK_HZ(CLK_FREQ_HZ),.COVER_SECONDS(10),.IMAGE_SECONDS(8)) u_playlist(.clk(clk),.rst(rst),.catalog_ready(catalog_ready),.source_done(load_done),.source_error(reader_error),
  .write_finish_toggle(write_finish_toggle),.next_press(next_press),.prev_press(prev_press),.auto_press(auto_press),.scale_change_toggle(scale_change_toggle),
  .narration_enable(nar_en_s),.narration_busy(narration_busy),
  .swap_ack_toggle(swap_ack_toggle),.load_start(load_start),.load_index(load_index),
  .write_buf_idx(write_buf_idx),.swap_toggle(swap_toggle),.swap_buffer(swap_buffer),.swap_image(swap_image),.auto_enabled(),.current_image(),.display_started(),.fault(playlist_error));
 bmp_read u_bmp(.clk(clk),.rst(rst),.sd_init_done(sd_init_done),.catalog_ready(catalog_ready),.found_mask(),.load_start(load_start),.load_index(load_index),
  .load_done(load_done),.error(reader_error),.state_code(reader_state),.write_req(write_req),.write_req_ack(write_req_ack),.write_sector_ready(source_sector_ready),
  .sd_sec_read(bmp_req),.sd_sec_read_addr(bmp_addr),.sd_sec_read_data(bmp_data),.sd_sec_read_data_valid(bmp_valid),.sd_sec_read_end(bmp_end),.bmp_data_wr_en(raw_write_en),.bmp_data(raw_rgb));
 bmp_frame_scaler u_frame_scaler(.clk(clk),.rst(rst),.scale_enable(scale_enable),.scale_level(scale_level),
  .write_req(write_req),.write_req_ack(write_req_ack),.downstream_ready(write_sector_ready),
  .source_we(raw_write_en),.source_data(raw_rgb),.source_sector_ready(source_sector_ready),.out_we(write_en),.out_data(rgb));
 audio_fat_stream #(.FIFO_AW(10)) u_bgm(.clk(clk),.rst(rst),.sd_init_done(sd_init_done),.sec_req(bgm_req),.sec_addr(bgm_addr),.sec_data(bgm_data),.sec_valid(bgm_valid),.sec_end(bgm_end),
  .fifo_we(bgm_we),.fifo_din(bgm_din),.fifo_full(bgm_full),.fifo_used({1'b0,bgm_used}),.ready(),.error(bgm_error),.state_code(bgm_state));
 narration_fat_stream #(.FIFO_AW(10)) u_nar(.clk(clk),.rst(rst),.sd_init_done(sd_init_done),.enable(nar_en_s),.file_index(nar_img_s),.play_toggle(nar_tog_s),.fifo_reset_busy(nar_fifo_reset_busy),
  .sec_req(nar_req),.sec_addr(nar_addr),.sec_data(nar_data),.sec_valid(nar_valid),.sec_end(nar_end),.fifo_we(nar_we),.fifo_din(nar_din),.fifo_full(nar_full),.fifo_used({1'b0,nar_used}),
  .catalog_ready(),.playing(nar_playing),.error(nar_error),.flush_toggle(nar_flush_toggle),.state_code(nar_state));
 sd_read_arbiter3 u_arb(.clk(clk),.rst(rst),.bmp_req(bmp_req),.bmp_addr(bmp_addr),.bmp_valid(bmp_valid),.bmp_data(bmp_data),.bmp_end(bmp_end),
  .bgm_req(bgm_req),.bgm_addr(bgm_addr),.bgm_valid(bgm_valid),.bgm_data(bgm_data),.bgm_end(bgm_end),.nar_req(nar_req),.nar_addr(nar_addr),.nar_valid(nar_valid),.nar_data(nar_data),.nar_end(nar_end),
  .sd_req(sec_read),.sd_addr(sec_address),.sd_valid(sec_valid),.sd_data(sec_data),.sd_end(sec_end));
 sd_card_top u_sd(.clk(clk),.rst(rst),.SD_nCS(SD_nCS),.SD_DCLK(SD_DCLK),.SD_MOSI(SD_MOSI),.SD_MISO(SD_MISO),.sd_init_done(sd_init_done),.sd_sec_read(sec_read),
  .sd_sec_read_addr(sec_address),.sd_sec_read_data(sec_data),.sd_sec_read_data_valid(sec_valid),.sd_sec_read_end(sec_end),.sd_sec_write(1'b0),.sd_sec_write_addr(32'd0),
  .sd_sec_write_data(),.sd_sec_write_data_req(),.sd_sec_write_end());
 wfifo_32_32_512 #(.ADDR_WIDTH_W(10),.ADDR_WIDTH_R(10),.AL_FULL_NUM(1021),.AL_EMPTY_NUM(2)) u_bgm_fifo(.clkw(clk),.clkr(audio_mclk),.rst(rst),.we(bgm_we),.di(bgm_din),.full_flag(bgm_full),.re(bgm_rd),
  .dout(bgm_dout),.empty_flag(bgm_empty),.valid(bgm_dvalid),.wrusedw(bgm_used),.afull(),.aempty(),.rdusedw());
 wfifo_32_32_512 #(.ADDR_WIDTH_W(10),.ADDR_WIDTH_R(10),.AL_FULL_NUM(1021),.AL_EMPTY_NUM(2)) u_nar_fifo(.clkw(clk),.clkr(audio_mclk),.rst(nar_fifo_rst),.we(nar_we),.di(nar_din),.full_flag(nar_full),.re(nar_rd),
  .dout(nar_dout),.empty_flag(nar_empty),.valid(nar_dvalid),.wrusedw(nar_used),.afull(),.aempty(),.rdusedw());
 pcm_audio_player u_bp(.mclk(audio_mclk),.rst(rst),.fifo_empty(bgm_empty),.fifo_rd(bgm_rd),.fifo_data(bgm_dout),.fifo_valid(bgm_dvalid),.sample_toggle(bgm_toggle),.left_sample(bgm_l),.right_sample(bgm_r),.sample_pulse(bgm_pulse));
 pcm_audio_player u_np(.mclk(audio_mclk),.rst(nar_fifo_rst),.fifo_empty(nar_empty||!nar_active_a),.fifo_rd(nar_rd),.fifo_data(nar_dout),.fifo_valid(nar_dvalid),.sample_toggle(nar_toggle),.left_sample(nar_l),.right_sample(nar_r),.sample_pulse(nar_pulse));
 audio_mix_duck u_mix(.clk(audio_mclk),.rst(rst),.bgm_enable(1'b1),.bgm_pulse(bgm_pulse),.bgm_left(bgm_l),.bgm_right(bgm_r),.nar_left(nar_l),.nar_right(nar_r),.narration_playing(nar_active_a),
  .sample_toggle(audio_toggle),.sample_pulse(),.left_sample(audio_left),.right_sample(audio_right));
 spectrum8_goertzel_bars u_spectrum(.clk(audio_mclk),.rst(rst),.sample_valid(bgm_pulse),.sample(audio_left),.levels(spectrum_levels));
endmodule

module key_press_debounce #(parameter integer CLK_FREQ_HZ=100000000,parameter integer DEBOUNCE_MS=20)(input clk,rst,button_in,output reg press_pulse);
 localparam integer CYCLES=(CLK_FREQ_HZ/1000)*DEBOUNCE_MS;reg meta,sync_button,stable;reg [31:0] count;
 always @(posedge clk or posedge rst)begin if(rst)begin meta<=1;sync_button<=1;stable<=1;count<=0;press_pulse<=0;end else begin meta<=button_in;sync_button<=meta;press_pulse<=0;
  if(sync_button==stable)count<=0;else if(count>=CYCLES-1)begin press_pulse<=stable&&!sync_button;stable<=sync_button;count<=0;end else count<=count+1'b1;end end
endmodule
