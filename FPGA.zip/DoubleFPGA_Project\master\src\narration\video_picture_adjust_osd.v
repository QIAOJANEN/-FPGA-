// Real-time RGB brightness/contrast adjustment and compact top-right OSD.
// Levels are signed -4..+4. When enable=0 the pixel path is an exact bypass.
module video_picture_adjust_osd(
 input clk,input rst,input enable,
 input key_bright_up_n,input key_bright_down_n,
 input key_contrast_up_n,input key_contrast_down_n,
 input vs_in,input de_in,input [23:0] rgb_in,
 output reg vs_out,output reg de_out,output reg [23:0] rgb_out);

 wire p_bu,p_bd,p_cu,p_cd;
 adjust_key_debounce u0(.clk(clk),.rst(rst),.key_n(key_bright_up_n),.pulse(p_bu));
 adjust_key_debounce u1(.clk(clk),.rst(rst),.key_n(key_bright_down_n),.pulse(p_bd));
 adjust_key_debounce u2(.clk(clk),.rst(rst),.key_n(key_contrast_up_n),.pulse(p_cu));
 adjust_key_debounce u3(.clk(clk),.rst(rst),.key_n(key_contrast_down_n),.pulse(p_cd));

 reg signed [3:0] bright_level,contrast_level;
 always @(posedge clk or posedge rst) begin
  if(rst)begin bright_level<=0;contrast_level<=0;end
  else if(enable)begin
   if(p_bu && bright_level<4)bright_level<=bright_level+1'b1;
   else if(p_bd && bright_level>-4)bright_level<=bright_level-1'b1;
   if(p_cu && contrast_level<4)contrast_level<=contrast_level+1'b1;
   else if(p_cd && contrast_level>-4)contrast_level<=contrast_level-1'b1;
  end
 end

 function signed [10:0] scale_contrast;
  input signed [8:0] d; input signed [3:0] level;
  begin case(level)
   -4:scale_contrast=d>>>1;                 // 0.50
   -3:scale_contrast=(d>>>1)+(d>>>3);       // 0.625
   -2:scale_contrast=(d>>>1)+(d>>>2);       // 0.75
   -1:scale_contrast=d-(d>>>3);             // 0.875
    1:scale_contrast=d+(d>>>3);             // 1.125
    2:scale_contrast=d+(d>>>2);             // 1.25
    3:scale_contrast=d+(d>>>1);             // 1.50
    4:scale_contrast=d<<<1;                 // 2.00
   default:scale_contrast=d;
  endcase end
 endfunction
 function [7:0] clamp8;
  input signed [11:0] v;
  begin if(v<0)clamp8=0;else if(v>255)clamp8=255;else clamp8=v[7:0];end
 endfunction

 reg signed [8:0] dr,dg,db;
 reg signed [11:0] ar,ag,ab;
 reg [23:0] adjusted;
 wire signed [11:0] brightness_offset={{4{bright_level[3]}},bright_level,4'b0000};
 always @* begin
  dr=$signed({1'b0,rgb_in[23:16]})-9'sd128;
  dg=$signed({1'b0,rgb_in[15:8]})-9'sd128;
  db=$signed({1'b0,rgb_in[7:0]})-9'sd128;
  ar=scale_contrast(dr,contrast_level)+12'sd128+brightness_offset;
  ag=scale_contrast(dg,contrast_level)+12'sd128+brightness_offset;
  ab=scale_contrast(db,contrast_level)+12'sd128+brightness_offset;
  adjusted={clamp8(ar),clamp8(ag),clamp8(ab)};
 end

 reg [9:0] x,y;reg vs_d;
 reg [2:0] font_x,font_y;reg [4:0] font_row;reg [15:0] zh_bits;reg glyph_on;
 reg [3:0] abs_b,abs_c;
 function [4:0] glyph;
  input [3:0] ch;input [2:0] row;
  begin case(ch)
   0:case(row)0:glyph=5'b11110;1:glyph=5'b10001;2:glyph=5'b11110;3:glyph=5'b10001;4:glyph=5'b10001;5:glyph=5'b10001;default:glyph=5'b11110;endcase // B
   1:case(row)0:glyph=5'b01110;1:glyph=5'b10001;2:glyph=5'b10000;3:glyph=5'b10000;4:glyph=5'b10000;5:glyph=5'b10001;default:glyph=5'b01110;endcase // C
   2:case(row)0:glyph=0;1:glyph=5'b00100;2:glyph=5'b00100;3:glyph=5'b11111;4:glyph=5'b00100;5:glyph=5'b00100;default:glyph=0;endcase // +
   3:case(row)3:glyph=5'b11111;default:glyph=0;endcase // -
   4:case(row)0:glyph=5'b01110;1:glyph=5'b10001;2:glyph=5'b10011;3:glyph=5'b10101;4:glyph=5'b11001;5:glyph=5'b10001;default:glyph=5'b01110;endcase // 0
   5:case(row)0:glyph=5'b00100;1:glyph=5'b01100;2:glyph=5'b00100;3:glyph=5'b00100;4:glyph=5'b00100;5:glyph=5'b00100;default:glyph=5'b01110;endcase // 1
   6:case(row)0:glyph=5'b01110;1:glyph=5'b10001;2:glyph=5'b00001;3:glyph=5'b00010;4:glyph=5'b00100;5:glyph=5'b01000;default:glyph=5'b11111;endcase // 2
   7:case(row)0:glyph=5'b11110;1:glyph=5'b00001;2:glyph=5'b00001;3:glyph=5'b01110;4:glyph=5'b00001;5:glyph=5'b00001;default:glyph=5'b11110;endcase // 3
   8:case(row)0:glyph=5'b00010;1:glyph=5'b00110;2:glyph=5'b01010;3:glyph=5'b10010;4:glyph=5'b11111;5:glyph=5'b00010;default:glyph=5'b00010;endcase // 4
   default:glyph=0;
  endcase end
 endfunction

 // 16x16 Song/Hei style glyphs: 0=亮, 1=度, 2=对, 3=比.
 function [15:0] zh_row;
  input [1:0] ch;input [3:0] row;
  begin case(ch)
   0:case(row)0:zh_row=16'h0100;1:zh_row=16'h7ffe;2:zh_row=16'h0000;3:zh_row=16'h0ff0;4:zh_row=16'h0810;5:zh_row=16'h0ff0;6:zh_row=16'h0000;7:zh_row=16'h7ffe;8:zh_row=16'h7ffe;9:zh_row=16'h4002;10:zh_row=16'h07e0;11:zh_row=16'h0460;12:zh_row=16'h0c62;13:zh_row=16'h387e;14:zh_row=16'h2000;default:zh_row=0;endcase
   1:case(row)0:zh_row=16'h0080;1:zh_row=16'h0080;2:zh_row=16'h3ffc;3:zh_row=16'h2210;4:zh_row=16'h2210;5:zh_row=16'h2ffc;6:zh_row=16'h2210;7:zh_row=16'h23f0;8:zh_row=16'h2000;9:zh_row=16'h2ff8;10:zh_row=16'h2310;11:zh_row=16'h21a0;12:zh_row=16'h60c0;13:zh_row=16'h473e;14:zh_row=16'h0802;default:zh_row=0;endcase
   2:case(row)0:zh_row=16'h0000;1:zh_row=16'h0008;2:zh_row=16'h0008;3:zh_row=16'h7e08;4:zh_row=16'h0208;5:zh_row=16'h03fe;6:zh_row=16'h2408;7:zh_row=16'h3488;8:zh_row=16'h1c88;9:zh_row=16'h0c48;10:zh_row=16'h0c48;11:zh_row=16'h1608;12:zh_row=16'h3208;13:zh_row=16'h6008;14:zh_row=16'h4038;default:zh_row=0;endcase
   default:case(row)0:zh_row=16'h0000;1:zh_row=16'h0080;2:zh_row=16'h2080;3:zh_row=16'h2080;4:zh_row=16'h2084;5:zh_row=16'h209c;6:zh_row=16'h3ef0;7:zh_row=16'h20c0;8:zh_row=16'h2080;9:zh_row=16'h2080;10:zh_row=16'h2080;11:zh_row=16'h2280;12:zh_row=16'h2e86;13:zh_row=16'h78c6;14:zh_row=16'h207c;default:zh_row=0;endcase
  endcase end
 endfunction

 always @* begin
  abs_b=bright_level[3] ? -bright_level : bright_level;
  abs_c=contrast_level[3] ? -contrast_level : contrast_level;
  font_x=0;font_y=0;font_row=0;zh_bits=0;glyph_on=0;
  // 亮度
  if(y>=8&&y<24&&x>=472&&x<488)begin zh_bits=zh_row(0,y-8);glyph_on=zh_bits[15-(x-472)];end
  else if(y>=8&&y<24&&x>=488&&x<504)begin zh_bits=zh_row(1,y-8);glyph_on=zh_bits[15-(x-488)];end
  // 亮度 sign and level
  else if(y>=9&&y<23&&x>=510&&x<520)begin font_x=(x-510)>>1;font_y=(y-9)>>1;font_row=glyph(bright_level[3]?3:2,font_y);glyph_on=font_row[4-font_x];end
  else if(y>=9&&y<23&&x>=522&&x<532)begin font_x=(x-522)>>1;font_y=(y-9)>>1;font_row=glyph(4+abs_b,font_y);glyph_on=font_row[4-font_x];end
  // 对比度
  else if(y>=8&&y<24&&x>=540&&x<556)begin zh_bits=zh_row(2,y-8);glyph_on=zh_bits[15-(x-540)];end
  else if(y>=8&&y<24&&x>=556&&x<572)begin zh_bits=zh_row(3,y-8);glyph_on=zh_bits[15-(x-556)];end
  else if(y>=8&&y<24&&x>=572&&x<588)begin zh_bits=zh_row(1,y-8);glyph_on=zh_bits[15-(x-572)];end
  // 对比度 sign and level
  else if(y>=9&&y<23&&x>=594&&x<604)begin font_x=(x-594)>>1;font_y=(y-9)>>1;font_row=glyph(contrast_level[3]?3:2,font_y);glyph_on=font_row[4-font_x];end
  else if(y>=9&&y<23&&x>=606&&x<616)begin font_x=(x-606)>>1;font_y=(y-9)>>1;font_row=glyph(4+abs_c,font_y);glyph_on=font_row[4-font_x];end
 end

 always @(posedge clk or posedge rst) begin
  if(rst)begin x<=0;y<=0;vs_d<=0;vs_out<=0;de_out<=0;rgb_out<=0;end
  else begin
   vs_d<=vs_in;
   if(vs_in&&!vs_d)begin x<=0;y<=0;end
   else if(de_in)begin if(x==639)begin x<=0;if(y<479)y<=y+1'b1;end else x<=x+1'b1;end
   vs_out<=vs_in;de_out<=de_in;
   if(!enable)rgb_out<=rgb_in;
   else if(de_in&&x>=464&&x<624&&y>=4&&y<28)begin
    if(glyph_on)rgb_out<=24'hffe070;else rgb_out<=24'h102038;
   end else rgb_out<=adjusted;
  end
 end
endmodule

module adjust_key_debounce(input clk,input rst,input key_n,output reg pulse);
 parameter integer COUNT_MAX=250000; // 10 ms at 25 MHz pixel clock
 reg meta,sync,stable;reg [18:0] count;
 always @(posedge clk or posedge rst)begin
  if(rst)begin meta<=1;sync<=1;stable<=1;count<=0;pulse<=0;end
  else begin meta<=key_n;sync<=meta;pulse<=0;
   if(sync==stable)count<=0;
   else if(count==COUNT_MAX-1)begin pulse<=stable&&!sync;stable<=sync;count<=0;end
   else count<=count+1'b1;
  end
 end
endmodule
