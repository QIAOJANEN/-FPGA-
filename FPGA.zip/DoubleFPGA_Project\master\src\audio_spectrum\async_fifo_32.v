module async_fifo_32 #(parameter AW=11)(
 input wr_clk,rd_clk,rst,input wr_en,input [31:0] din,output full,
 input rd_en,output reg [31:0] dout,output empty,output reg rd_valid,
 output [AW:0] wr_used);
 localparam PW=AW+1;
 reg [31:0] mem[0:(1<<AW)-1];
 reg [PW-1:0] wbin,wgray,rbin,rgray;
 reg [PW-1:0] rq1_wgray,rq2_wgray,wq1_rgray,wq2_rgray;
 wire [PW-1:0] wbin_next=wbin+(wr_en&&!full);
 wire [PW-1:0] rbin_next=rbin+(rd_en&&!empty);
 wire [PW-1:0] wgray_next=(wbin_next>>1)^wbin_next;
 wire [PW-1:0] rgray_next=(rbin_next>>1)^rbin_next;
 wire [PW-1:0] rbin_sync=gray2bin(wq2_rgray);
 assign full=(wgray_next=={~wq2_rgray[PW-1:PW-2],wq2_rgray[PW-3:0]});
 assign empty=(rgray==rq2_wgray);
 assign wr_used=wbin-rbin_sync;
 function [PW-1:0] gray2bin; input [PW-1:0] g; integer i; begin
   gray2bin[PW-1]=g[PW-1]; for(i=PW-2;i>=0;i=i-1) gray2bin[i]=gray2bin[i+1]^g[i];
 end endfunction
 always @(posedge wr_clk or posedge rst) begin
   if(rst) begin wbin<=0;wgray<=0;wq1_rgray<=0;wq2_rgray<=0; end else begin
     wq1_rgray<=rgray;wq2_rgray<=wq1_rgray;
     if(wr_en&&!full) begin mem[wbin[AW-1:0]]<=din;wbin<=wbin_next;wgray<=wgray_next;end
   end
 end
 always @(posedge rd_clk or posedge rst) begin
   if(rst) begin rbin<=0;rgray<=0;rq1_wgray<=0;rq2_wgray<=0;dout<=0;rd_valid<=0;end else begin
     rq1_wgray<=wgray;rq2_wgray<=rq1_wgray;rd_valid<=0;
     if(rd_en&&!empty) begin dout<=mem[rbin[AW-1:0]];rbin<=rbin_next;rgray<=rgray_next;rd_valid<=1;end
   end
 end
endmodule
