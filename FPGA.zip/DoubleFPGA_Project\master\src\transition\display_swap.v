// CDC mailbox: switch only at the vertical-blank frame request. Acknowledge
// only after the SDRAM reader has drained old reads and latched the new base.
module display_swap(
    input clk, rst,
    input frame_req,
    output frame_ack,
    output reg memory_req,
    input memory_ack,
    input swap_toggle,
    input manual_transition_toggle,
    input [1:0] swap_buffer,
    input [3:0] swap_image,
    input [1:0] swap_effect,
    output reg ack_toggle,
    output reg [1:0] display_buffer,
    output reg [3:0] display_image,
    output reg display_valid,
    output reg [5:0] fade_gain,
    output reg [1:0] transition_mode
);
reg [2:0] request_sync;
reg [1:0] ack_sync;
reg [1:0] buffer_meta, buffer_sync;
reg [3:0] image_meta, image_sync;
reg [1:0] effect_meta,effect_sync;
reg [2:0] state;
reg [2:0] guard_count;
reg transaction_swap, transaction_token, transaction_same_image;
reg [3:0] transaction_image;
reg [1:0] transaction_effect;
reg fading_in;
localparam [5:0] FADE_STEP = 6'd1;
wire pending_swap = request_sync[2] != ack_toggle;
wire same_image_swap = pending_swap && display_valid && (image_sync == display_image);
// 32 frame steps per ramp, about 0.54 seconds at 59.52 Hz.  Fade-out begins
// only after the complete target frame is ready; a cold load leaves the
// current image at full brightness.
// First frame is committed black; later changes fade the old frame to black
// before latching a different buffer. Never acknowledge a merely pending swap.
assign frame_ack = (state == 3);
always @(posedge clk or posedge rst) begin
    if (rst) begin
        request_sync<=0; ack_sync<=0; buffer_meta<=0; buffer_sync<=0;
        image_meta<=0; image_sync<=0;effect_meta<=0;effect_sync<=0;state<=0;guard_count<=0;
        transaction_swap<=0;transaction_token<=0;transaction_same_image<=0;transaction_image<=0;transaction_effect<=0;
        memory_req<=0; ack_toggle<=0; display_buffer<=0;
        display_image<=0;display_valid<=0;fade_gain<=0;fading_in<=0;transition_mode<=0;
    end else begin
        request_sync<={request_sync[1:0],swap_toggle};
        ack_sync<={ack_sync[0],memory_ack};
        buffer_meta<=swap_buffer; buffer_sync<=buffer_meta;
        image_meta<=swap_image; image_sync<=image_meta;
        effect_meta<=swap_effect;effect_sync<=effect_meta;
        case (state)
        0: if (frame_req && !ack_sync[1]) begin
            transaction_swap <= pending_swap &&
                (same_image_swap || !display_valid || (!fading_in && fade_gain==0));
            transaction_token <= request_sync[2];
            transaction_same_image <= same_image_swap;
            transaction_image <= image_sync;
            transaction_effect <= effect_sync;
            if(pending_swap && display_valid && !fading_in)transition_mode<=effect_sync;
            if (same_image_swap) begin
                fade_gain<=6'd32;
                fading_in<=1'b0;
            end else if (fading_in) begin
                if(fade_gain>=6'd28) begin fade_gain<=6'd32; fading_in<=0; end
                else fade_gain<=fade_gain+FADE_STEP;
            end else if(pending_swap && display_valid && fade_gain!=0)
                // The complete target frame is ready: finish fading to black
                // and commit it at the vertical-blank memory handshake.
                fade_gain<=(fade_gain<=FADE_STEP) ? 6'd0 : fade_gain-FADE_STEP;
            if (pending_swap &&
                (same_image_swap || !display_valid || (!fading_in && fade_gain==0))) begin
                // The reader needs the buffer selection before memory_req,
                // but the public image number must not change until the
                // reader acknowledges that the new base address is active.
                display_buffer<=buffer_sync;
            end
            guard_count<=0; state<=1;
        end
        1: if (guard_count == 4) begin memory_req<=1; state<=2; end
           else guard_count<=guard_count+1'b1;
        2: if (ack_sync[1]) begin
            memory_req<=0;
            if (transaction_swap) begin
                ack_toggle<=transaction_token; display_valid<=1;
                display_image<=transaction_image;
                transition_mode<=transaction_effect;
                if(transaction_same_image) begin fade_gain<=6'd32; fading_in<=1'b0; end
                else begin fade_gain<=0; fading_in<=1; end
            end
            state<=3;
        end
        3: if (!frame_req && !ack_sync[1]) state<=0;
        default: state<=0;
        endcase
    end
end
endmodule

// Pixel-domain masks for the two non-fade transitions.  progress runs
// 32->0 before the atomic buffer swap and 0->32 after it.
module transition_effect_mask(
 input clk,input rst,input vs_in,input de_in,input [23:0] rgb_in,
 input [1:0] mode,input [5:0] progress,
 output reg vs_out,output reg de_out,output reg [23:0] rgb_out);
 reg [9:0] x;reg [9:0] y;reg vs_d;
 wire [10:0] curtain_edge=({5'b0,progress}<<4)+({5'b0,progress}<<2);
 wire [6:0] blind_open={progress,1'b0};
 wire visible=(mode==0) ? 1'b1 :
              (mode==1) ? ({1'b0,x}<curtain_edge) :
              ({1'b0,x[5:0]}<blind_open);
 always @(posedge clk or posedge rst)begin
  if(rst)begin x<=0;y<=0;vs_d<=0;vs_out<=0;de_out<=0;rgb_out<=0;end
  else begin
   vs_d<=vs_in;
   if(vs_in&&!vs_d)begin x<=0;y<=0;end
   else if(de_in)begin
    if(x==639)begin x<=0;if(y<479)y<=y+1'b1;end else x<=x+1'b1;
   end
   vs_out<=vs_in;de_out<=de_in;
   rgb_out<=(de_in&&visible)?rgb_in:24'h000000;
  end
 end
endmodule
