// Read-only FAT16/FAT32 root-directory player. 512-byte sectors, SDHC block LBAs.
// Files: 00.BMP .. 13.BMP. Windows BMP, 24-bit BI_RGB, positive height, offset 54.
// Follows FAT chains (including fragmented files and FAT32 root directories).
module bmp_read #(
    parameter integer WIDTH=640, HEIGHT=480,
    parameter integer IO_TIMEOUT=100000000
)(
    input clk, rst, sd_init_done,
    output reg catalog_ready,
    output reg [13:0] found_mask,
    input load_start,
    input [3:0] load_index,
    output reg load_done,
    output wire error,
    output wire [3:0] state_code,
    output reg write_req,
    input write_req_ack, write_sector_ready,
    output reg sd_sec_read,
    output reg [31:0] sd_sec_read_addr,
    input [7:0] sd_sec_read_data,
    input sd_sec_read_data_valid, sd_sec_read_end,
    output reg bmp_data_wr_en,
    output reg [23:0] bmp_data
);
localparam integer PIXEL_END=54+WIDTH*HEIGHT*3;
localparam WAIT_SD=0, BOOT_READ=1, BOOT_CHECK=2, LAYOUT1=3, LAYOUT2=4,
    LAYOUT3=5, ROOT_START=6, MAP1=7, MAP2=8, MAP3=9, DIR_READ=10,
    DIR_END=11, NEXT_SECTOR=12, FAT_START=13, FAT_END=14, IDLE=15,
    LOAD_BEGIN=16, HEADER_READ=17, HEADER_CHECK=18, WRITE_WAIT=19,
    DATA_READ=20, DATA_END=21, IO_START=22, IO_WAIT=23, FAIL=24,
    LAYOUT4=25, LAYOUT5=26, LAYOUT6=27;
localparam CT_BOOT=0, CT_DIR=1, CT_FAT=2, CT_HEADER=3, CT_DATA=4;
reg [4:0] state, io_return, map_return, next_return;
reg [2:0] context_id;
reg [31:0] io_address, timeout_count;
reg [9:0] byte_count;
wire [8:0] byte_offset=byte_count[8:0];
wire [4:0] entry_offset=byte_count[4:0];
reg [3:0] error_code;
assign error=(state==FAIL);
assign state_code=error ? error_code : !sd_init_done ? 4'h0 : !catalog_ready ? 4'h1 :
                  (state==IDLE) ? 4'h3 : 4'h2;
reg [1:0] write_ack_sync;

reg [31:0] partition_lba, mbr_lba, total_sectors, total32, fat32_size, root_cluster;
reg [15:0] signature, bytes_per_sector, reserved_sectors, root_entries;
reg [15:0] fat16_size, total16, fat_flags;
reg [7:0] sectors_per_cluster, fat_count;
reg [3:0] cluster_shift;
reg vbr_attempted, is_fat32;
reg [31:0] fat_base, fat_area, root_base, root_sectors, data_base, cluster_count;
reg [31:0] data_offset, data_sectors, fat_capacity;
reg [31:0] current_cluster, cluster_offset, cluster_lba, sector_lba;
reg [7:0] sector_in_cluster;
reg [31:0] root_remaining;
reg walking_directory;
reg [15:0] directory_sector_count;
reg [31:0] file_cluster [0:13];
reg [31:0] file_size [0:13];

reg directory_end, entry_match, tens_one;
reg [3:0] entry_index;
reg [31:0] entry_cluster, entry_size;
reg [7:0] entry_attr;
reg [8:0] fat_byte_offset;
reg [31:0] fat_value;
wire [31:0] next_cluster=is_fat32 ? {4'b0,fat_value[27:0]} : {16'b0,fat_value[15:0]};
wire fat_eoc=is_fat32 ? (next_cluster>=32'h0ffffff8) : (next_cluster>=32'hfff8);
wire fat_bad=is_fat32 ? (next_cluster>=32'h0ffffff0) : (next_cluster>=32'hfff0);

reg [15:0] bmp_magic, bmp_planes, bmp_bits;
reg [31:0] bmp_offset, dib_size, bmp_width, bmp_height, compression, header_size;
reg [31:0] selected_size;
reg [19:0] file_position;
reg [1:0] color_phase;
reg [7:0] blue, green;
wire bpb_valid=(signature==16'haa55 && bytes_per_sector==512 && reserved_sectors!=0 &&
    (fat_count==1 || fat_count==2) && (fat16_size!=0 || fat32_size!=0) &&
    (sectors_per_cluster==1 || sectors_per_cluster==2 || sectors_per_cluster==4 ||
     sectors_per_cluster==8 || sectors_per_cluster==16 || sectors_per_cluster==32 ||
     sectors_per_cluster==64 || sectors_per_cluster==128));

always @(posedge clk or posedge rst) begin
    if (rst) begin
        state<=WAIT_SD; io_return<=0; map_return<=0; next_return<=0; context_id<=0;
        io_address<=0; timeout_count<=0; byte_count<=0; error_code<=4'he;
        catalog_ready<=0; found_mask<=0; load_done<=0; write_req<=0;
        sd_sec_read<=0; sd_sec_read_addr<=0; bmp_data_wr_en<=0; bmp_data<=0;
        write_ack_sync<=0; partition_lba<=0; mbr_lba<=0; vbr_attempted<=0;
        total_sectors<=0; total32<=0; total16<=0; fat32_size<=0; root_cluster<=0;
        signature<=0; bytes_per_sector<=0; reserved_sectors<=0; root_entries<=0;
        fat16_size<=0; fat_flags<=0; sectors_per_cluster<=0; fat_count<=0; cluster_shift<=0;
        is_fat32<=0; fat_base<=0; fat_area<=0; root_base<=0; root_sectors<=0;
        data_base<=0; cluster_count<=0; data_offset<=0; data_sectors<=0; fat_capacity<=0;
        current_cluster<=0; cluster_offset<=0;
        cluster_lba<=0; sector_lba<=0; sector_in_cluster<=0; root_remaining<=0;
        walking_directory<=0; directory_sector_count<=0; directory_end<=0;
        entry_match<=0; tens_one<=0; entry_index<=0; entry_cluster<=0; entry_size<=0; entry_attr<=0;
        fat_byte_offset<=0; fat_value<=0;
        bmp_magic<=0; bmp_planes<=0; bmp_bits<=0; bmp_offset<=0; dib_size<=0;
        bmp_width<=0; bmp_height<=0; compression<=0; header_size<=0; selected_size<=0;
        file_position<=0; color_phase<=0; blue<=0; green<=0;
    end else begin
        write_ack_sync<={write_ack_sync[0],write_req_ack};
        load_done<=0; bmp_data_wr_en<=0;
        case (state)
        WAIT_SD: if (sd_init_done) state<=BOOT_READ;
        BOOT_READ: begin
            io_address<=partition_lba; context_id<=CT_BOOT; io_return<=BOOT_CHECK; state<=IO_START;
        end
        BOOT_CHECK: if (bpb_valid) begin
            is_fat32<=fat16_size==0;
            case (sectors_per_cluster)
            1: cluster_shift<=0; 2: cluster_shift<=1; 4: cluster_shift<=2; 8: cluster_shift<=3;
            16: cluster_shift<=4; 32: cluster_shift<=5; 64: cluster_shift<=6; 128: cluster_shift<=7;
            endcase
            total_sectors<=(total16!=0) ? {16'b0,total16} : total32;
            state<=LAYOUT1;
        end else if (!vbr_attempted && signature==16'haa55 && mbr_lba!=0) begin
            partition_lba<=mbr_lba; vbr_attempted<=1; state<=BOOT_READ;
        end else begin error_code<=4'he; state<=FAIL; end
        LAYOUT1: begin
            fat_base<=partition_lba+{16'b0,reserved_sectors};
            fat_area<=(fat16_size!=0 ? {16'b0,fat16_size} : fat32_size) << (fat_count==2);
            fat_capacity<=is_fat32 ? (fat32_size<<7) : ({16'b0,fat16_size}<<8);
            root_sectors<=({16'b0,root_entries}+32'd15)>>4;
            state<=LAYOUT2;
        end
        LAYOUT2: begin
            root_base<=fat_base+fat_area;
            // FAT32 may select its second FAT when mirroring is disabled.
            if (is_fat32 && fat_flags[7]) begin
                if (fat_flags[3:0]>=fat_count) begin error_code<=4'he; state<=FAIL; end
                else begin
                    if (fat_flags[0]) fat_base<=fat_base+fat32_size;
                    state<=LAYOUT3;
                end
            end else state<=LAYOUT3;
        end
        LAYOUT3: begin data_base<=root_base+root_sectors; state<=LAYOUT4; end
        LAYOUT4: begin
            data_offset<=data_base-partition_lba;
            state<=LAYOUT5;
        end
        LAYOUT5: begin
            data_sectors<=total_sectors-data_offset;
            if (data_base<partition_lba || total_sectors<=data_offset) begin
                error_code<=4'he; state<=FAIL;
            end else state<=LAYOUT6;
        end
        LAYOUT6: begin
            cluster_count<=data_sectors >> cluster_shift;
            state<=ROOT_START;
        end
        ROOT_START: begin
            walking_directory<=1; directory_end<=0; directory_sector_count<=0;
            sector_in_cluster<=0; map_return<=DIR_READ;
            if (cluster_count<4085 || cluster_count+32'd2>fat_capacity ||
                (is_fat32 && (cluster_count<65525 || root_cluster<2 || root_entries!=0)) ||
                (!is_fat32 && (cluster_count>=65525 || root_entries==0))) begin
                error_code<=4'he; state<=FAIL;
            end else if (is_fat32) begin current_cluster<=root_cluster; state<=MAP1; end
            else begin sector_lba<=root_base; root_remaining<=root_sectors; state<=DIR_READ; end
        end
        MAP1: if (current_cluster<2 || current_cluster-2>=cluster_count) begin
            error_code<=4'he; state<=FAIL;
        end else begin cluster_offset<=current_cluster-2; state<=MAP2; end
        MAP2: begin cluster_offset<=cluster_offset<<cluster_shift; state<=MAP3; end
        MAP3: begin
            cluster_lba<=data_base+cluster_offset; sector_lba<=data_base+cluster_offset;
            sector_in_cluster<=0; state<=map_return;
        end
        DIR_READ: begin
            context_id<=CT_DIR; io_address<=sector_lba; io_return<=DIR_END; state<=IO_START;
        end
        DIR_END: begin
            directory_sector_count<=directory_sector_count+1'b1;
            if (&found_mask) begin catalog_ready<=1; state<=IDLE; end
            else if (directory_end || directory_sector_count==4095) begin error_code<=4'he; state<=FAIL; end
            else if (!is_fat32) begin
                if (root_remaining<=1) begin error_code<=4'he; state<=FAIL; end
                else begin root_remaining<=root_remaining-1'b1; sector_lba<=sector_lba+1'b1; state<=DIR_READ; end
            end else begin next_return<=DIR_READ; state<=NEXT_SECTOR; end
        end
        NEXT_SECTOR: if (sector_in_cluster+8'd1 < sectors_per_cluster) begin
            sector_in_cluster<=sector_in_cluster+1'b1; sector_lba<=sector_lba+1'b1; state<=next_return;
        end else state<=FAT_START;
        FAT_START: begin
            io_address<=fat_base+(is_fat32 ? (current_cluster>>7) : (current_cluster>>8));
            fat_byte_offset<=is_fat32 ? {current_cluster[6:0],2'b0} : {current_cluster[7:0],1'b0};
            fat_value<=0; context_id<=CT_FAT; io_return<=FAT_END; state<=IO_START;
        end
        FAT_END: if (fat_eoc || fat_bad || next_cluster<2 || next_cluster==current_cluster) begin
            error_code<=4'he; state<=FAIL;
        end else begin current_cluster<=next_cluster; map_return<=next_return; state<=MAP1; end
        IDLE: if (load_start) begin
            if (load_index<14 && found_mask[load_index]) begin
                current_cluster<=file_cluster[load_index]; selected_size<=file_size[load_index];
                walking_directory<=0; map_return<=HEADER_READ; state<=MAP1;
            end else begin error_code<=4'he; state<=FAIL; end
        end
        HEADER_READ: begin
            context_id<=CT_HEADER; io_address<=sector_lba; io_return<=HEADER_CHECK; state<=IO_START;
        end
        HEADER_CHECK: if (bmp_magic==16'h4d42 && dib_size==40 && bmp_width==WIDTH && bmp_height==HEIGHT &&
            bmp_planes==1 && bmp_bits==24 && compression==0 && bmp_offset==54 &&
            selected_size>=PIXEL_END && header_size>=PIXEL_END && header_size<=selected_size) begin
            write_req<=1; timeout_count<=0; state<=WRITE_WAIT;
        end else begin error_code<=4'hd; state<=FAIL; end
        WRITE_WAIT: if (write_ack_sync[1]) begin
            write_req<=0; file_position<=0; color_phase<=0; timeout_count<=0; state<=DATA_READ;
        end else if (timeout_count==IO_TIMEOUT-1) begin error_code<=4'hf; state<=FAIL; end
        else timeout_count<=timeout_count+1'b1;
        DATA_READ: if (write_sector_ready && !write_ack_sync[1]) begin
            io_address<=sector_lba; context_id<=CT_DATA; io_return<=DATA_END; state<=IO_START;
        end else if (timeout_count==IO_TIMEOUT-1) begin error_code<=4'hf; state<=FAIL; end
        else timeout_count<=timeout_count+1'b1;
        DATA_END: begin
            timeout_count<=0;
            if (file_position>=PIXEL_END) begin load_done<=1; state<=IDLE; end
            else begin next_return<=DATA_READ; state<=NEXT_SECTOR; end
        end
        IO_START: begin
            byte_count<=0; timeout_count<=0;
            sd_sec_read_addr<=io_address; sd_sec_read<=1; state<=IO_WAIT;
        end
        IO_WAIT: begin
            timeout_count<=timeout_count+1'b1;
            if (sd_sec_read_end) begin
                sd_sec_read<=0;
                // The board driver ends one cycle after the final byte. Also
                // accept a transport that coincides its final valid with end.
                if (byte_count==512 || (byte_count==511 && sd_sec_read_data_valid)) begin
                    timeout_count<=0; state<=io_return;
                end
                else begin error_code<=4'hf; state<=FAIL; end
            end else if (timeout_count==IO_TIMEOUT-1) begin
                error_code<=4'hf; state<=FAIL;
            end
            if (sd_sec_read_data_valid && byte_count<512) begin
                byte_count<=byte_count+1'b1;
                case (context_id)
                CT_BOOT: begin
                    case (byte_offset)
                    11: bytes_per_sector[7:0]<=sd_sec_read_data;
                    12: bytes_per_sector[15:8]<=sd_sec_read_data;
                    13: sectors_per_cluster<=sd_sec_read_data;
                    14: reserved_sectors[7:0]<=sd_sec_read_data;
                    15: reserved_sectors[15:8]<=sd_sec_read_data;
                    16: fat_count<=sd_sec_read_data;
                    17: root_entries[7:0]<=sd_sec_read_data;
                    18: root_entries[15:8]<=sd_sec_read_data;
                    19: total16[7:0]<=sd_sec_read_data;
                    20: total16[15:8]<=sd_sec_read_data;
                    22: fat16_size[7:0]<=sd_sec_read_data;
                    23: fat16_size[15:8]<=sd_sec_read_data;
                    40: fat_flags[7:0]<=sd_sec_read_data;
                    41: fat_flags[15:8]<=sd_sec_read_data;
                    510: signature[7:0]<=sd_sec_read_data;
                    511: signature[15:8]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    32: total32[7:0]<=sd_sec_read_data;
                    33: total32[15:8]<=sd_sec_read_data;
                    34: total32[23:16]<=sd_sec_read_data;
                    35: total32[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    36: fat32_size[7:0]<=sd_sec_read_data;
                    37: fat32_size[15:8]<=sd_sec_read_data;
                    38: fat32_size[23:16]<=sd_sec_read_data;
                    39: fat32_size[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    44: root_cluster[7:0]<=sd_sec_read_data;
                    45: root_cluster[15:8]<=sd_sec_read_data;
                    46: root_cluster[23:16]<=sd_sec_read_data;
                    47: root_cluster[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    454: mbr_lba[7:0]<=sd_sec_read_data;
                    455: mbr_lba[15:8]<=sd_sec_read_data;
                    456: mbr_lba[23:16]<=sd_sec_read_data;
                    457: mbr_lba[31:24]<=sd_sec_read_data;
                    endcase
                end
                CT_DIR: if (!directory_end) begin
                    case (entry_offset)
                    0: begin
                        if (sd_sec_read_data==0) directory_end<=1;
                        entry_match<=(sd_sec_read_data==8'h30 || sd_sec_read_data==8'h31);
                        tens_one<=sd_sec_read_data==8'h31; entry_cluster<=0; entry_size<=0;
                    end
                    1: begin
                        if (sd_sec_read_data<8'h30 || sd_sec_read_data>8'h39 ||
                            (tens_one && sd_sec_read_data>8'h33)) entry_match<=0;
                        entry_index<=tens_one ? (4'd10+sd_sec_read_data[3:0]) : sd_sec_read_data[3:0];
                    end
                    2,3,4,5,6,7: if (sd_sec_read_data!=8'h20) entry_match<=0;
                    8: if (sd_sec_read_data!=8'h42) entry_match<=0;
                    9: if (sd_sec_read_data!=8'h4d) entry_match<=0;
                    10: if (sd_sec_read_data!=8'h50) entry_match<=0;
                    11: entry_attr<=sd_sec_read_data;
                    20: if (is_fat32) entry_cluster[23:16]<=sd_sec_read_data;
                    21: if (is_fat32) entry_cluster[31:24]<=sd_sec_read_data;
                    26: entry_cluster[7:0]<=sd_sec_read_data;
                    27: entry_cluster[15:8]<=sd_sec_read_data;
                    28: entry_size[7:0]<=sd_sec_read_data;
                    29: entry_size[15:8]<=sd_sec_read_data;
                    30: entry_size[23:16]<=sd_sec_read_data;
                    31: if (entry_match && entry_index<14 && !entry_attr[4] && !entry_attr[3] &&
                            entry_cluster>=2 && {sd_sec_read_data,entry_size[23:0]}>=PIXEL_END) begin
                        file_cluster[entry_index]<=entry_cluster;
                        file_size[entry_index]<={sd_sec_read_data,entry_size[23:0]};
                        found_mask[entry_index]<=1;
                    end
                    endcase
                end
                CT_FAT: begin
                    if (is_fat32 && byte_offset[8:2]==fat_byte_offset[8:2]) begin
                        case (byte_offset[1:0])
                        0: fat_value[7:0]<=sd_sec_read_data;
                        1: fat_value[15:8]<=sd_sec_read_data;
                        2: fat_value[23:16]<=sd_sec_read_data;
                        3: fat_value[31:24]<=sd_sec_read_data;
                        endcase
                    end
                    if (!is_fat32 && byte_offset[8:1]==fat_byte_offset[8:1]) begin
                        if (!byte_offset[0]) fat_value[7:0]<=sd_sec_read_data;
                        else fat_value[15:8]<=sd_sec_read_data;
                    end
                end
                CT_HEADER: begin
                    case (byte_offset)
                    0: bmp_magic[7:0]<=sd_sec_read_data; 1: bmp_magic[15:8]<=sd_sec_read_data;
                    26: bmp_planes[7:0]<=sd_sec_read_data; 27: bmp_planes[15:8]<=sd_sec_read_data;
                    28: bmp_bits[7:0]<=sd_sec_read_data; 29: bmp_bits[15:8]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    2: header_size[7:0]<=sd_sec_read_data;
                    3: header_size[15:8]<=sd_sec_read_data;
                    4: header_size[23:16]<=sd_sec_read_data;
                    5: header_size[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    10: bmp_offset[7:0]<=sd_sec_read_data;
                    11: bmp_offset[15:8]<=sd_sec_read_data;
                    12: bmp_offset[23:16]<=sd_sec_read_data;
                    13: bmp_offset[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    14: dib_size[7:0]<=sd_sec_read_data;
                    15: dib_size[15:8]<=sd_sec_read_data;
                    16: dib_size[23:16]<=sd_sec_read_data;
                    17: dib_size[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    18: bmp_width[7:0]<=sd_sec_read_data;
                    19: bmp_width[15:8]<=sd_sec_read_data;
                    20: bmp_width[23:16]<=sd_sec_read_data;
                    21: bmp_width[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    22: bmp_height[7:0]<=sd_sec_read_data;
                    23: bmp_height[15:8]<=sd_sec_read_data;
                    24: bmp_height[23:16]<=sd_sec_read_data;
                    25: bmp_height[31:24]<=sd_sec_read_data;
                    endcase
                    case (byte_offset)
                    30: compression[7:0]<=sd_sec_read_data;
                    31: compression[15:8]<=sd_sec_read_data;
                    32: compression[23:16]<=sd_sec_read_data;
                    33: compression[31:24]<=sd_sec_read_data;
                    endcase
                end
                CT_DATA: begin
                    if (file_position<PIXEL_END) file_position<=file_position+1'b1;
                    if (file_position>=54 && file_position<PIXEL_END) begin
                        case (color_phase)
                        0: begin blue<=sd_sec_read_data; color_phase<=1; end
                        1: begin green<=sd_sec_read_data; color_phase<=2; end
                        2: begin bmp_data<={sd_sec_read_data,green,blue}; bmp_data_wr_en<=1; color_phase<=0; end
                        endcase
                    end
                end
                endcase
            end
        end
        FAIL: begin sd_sec_read<=0; write_req<=0; end
        default: begin error_code<=4'hf; state<=FAIL; end
        endcase
    end
end
endmodule
