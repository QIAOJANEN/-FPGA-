// Two SDRAM buffers, fourteen files. Payload stays stable until swap acknowledgement.
module playlist14_legacy #(
    parameter integer CLK_HZ = 100000000,
    parameter integer COVER_SECONDS = 12,
    parameter integer IMAGE_SECONDS = 5
)(
    input clk, rst, catalog_ready, source_done, source_error,
    input write_finish_toggle, next_press, prev_press, auto_press, scale_change_toggle,
    input narration_enable, narration_busy,
    input swap_ack_toggle,
    output reg load_start,
    output reg [3:0] load_index,
    output reg [1:0] write_buf_idx,
    output reg swap_toggle,
    output reg manual_transition_toggle,
    output reg [1:0] swap_buffer,
    output reg [3:0] swap_image,
    output reg auto_enabled,
    output reg [3:0] current_image,
    output reg display_started,
    output wire fault
);
localparam BOOT=0, LOADING=1, READY=2, SWAPPING=3, FAILED=4;
reg [2:0] state;
reg [2:0] finish_sync, ack_sync;
reg source_seen, finish_seen, next_pending, prev_pending;
reg [2:0] scale_sync;
reg scale_pending,reload_active,reload_ready;
reg [31:0] seconds_div;
reg [3:0] seconds_count;
wire finished = finish_sync[2] ^ finish_sync[1];
wire scale_event = scale_sync[2] ^ scale_sync[1];
// Keep the normal minimum dwell time, but do not interrupt an enabled narration.
// Manual next_press remains an immediate override in the READY state below.
wire auto_due = auto_enabled && !auto_press && display_started &&
                (seconds_count >= ((current_image == 0) ? COVER_SECONDS : IMAGE_SECONDS)) &&
                (!narration_enable || !narration_busy);
assign fault = state == FAILED;
always @(posedge clk or posedge rst) begin
    if (rst) begin
        state<=BOOT; finish_sync<=0; ack_sync<=0;
        source_seen<=0; finish_seen<=0; next_pending<=0; prev_pending<=0;
        scale_sync<=0;scale_pending<=0;reload_active<=0;reload_ready<=0;
        seconds_div<=0; seconds_count<=0;
        load_start<=0; load_index<=0; write_buf_idx<=0;
        swap_toggle<=0; manual_transition_toggle<=0; swap_buffer<=0; swap_image<=0;
        auto_enabled<=0; current_image<=0; display_started<=0;
    end else begin
        finish_sync <= {finish_sync[1:0],write_finish_toggle};
        ack_sync <= {ack_sync[1:0],swap_ack_toggle};
        scale_sync <= {scale_sync[1:0],scale_change_toggle};
        if(scale_event) scale_pending<=1;
        load_start <= 0;
        if (auto_press) begin
            auto_enabled <= ~auto_enabled;
            seconds_div<=0; seconds_count<=0;
        end else if (auto_enabled && display_started && !auto_due) begin
            if (seconds_div == CLK_HZ-1) begin
                seconds_div<=0;
                if(seconds_count!=4'hf) seconds_count<=seconds_count+1'b1;
            end else seconds_div<=seconds_div+1'b1;
        end
        // A press during prefetch is remembered; repeated presses coalesce to one.
        if (next_press) next_pending<=1;
        if (prev_press) prev_pending<=1;
        // Tell the video domain immediately that a manual navigation was
        // accepted.  Frame loading and the eventual atomic swap remain
        // separate, so the old complete frame can fade while the new one is
        // prepared in the free buffer.
        if (display_started && (next_press || prev_press))
            manual_transition_toggle<=~manual_transition_toggle;
        case (state)
        BOOT: if (catalog_ready) begin
            load_index<=0; write_buf_idx<=0; load_start<=1;
            source_seen<=0; finish_seen<=0; state<=LOADING;
        end
        LOADING: begin
            if (source_done) source_seen<=1;
            if (finished) finish_seen<=1;
            if (source_error) state<=FAILED;
            else if ((source_seen || source_done) && (finish_seen || finished)) begin
                if(reload_active)reload_ready<=1;
                state<=READY;
            end
        end
        READY: if((prev_pending||prev_press) && display_started && !reload_ready)begin
            // The free buffer normally contains the next image. Replace it with
            // the previous image, then commit that buffer through reload_ready.
            load_index<=(current_image==0)?4'd13:current_image-1'b1;
            load_start<=1;source_seen<=0;finish_seen<=0;
            prev_pending<=0;next_pending<=0;reload_active<=1;state<=LOADING;
        end else if(scale_pending && display_started && !reload_ready)begin
            // Discard the prefetched next frame and rebuild the currently shown
            // picture into that free buffer using the newly selected scale.
            load_index<=current_image;load_start<=1;source_seen<=0;finish_seen<=0;
            scale_pending<=0;reload_active<=1;state<=LOADING;
        end else if (!display_started || reload_ready || next_pending || next_press || auto_due) begin
            swap_buffer<=write_buf_idx;
            swap_image<=load_index;
            swap_toggle<=~swap_toggle;
            // The initial cover commit must not consume a press queued while
            // the first image was loading. That press advances AFTER the cover.
            if (display_started) begin next_pending<=0;prev_pending<=0;end
            state<=SWAPPING;
        end
        SWAPPING: if (ack_sync[2] == swap_toggle) begin
            current_image<=load_index;
            display_started<=1;
            seconds_div<=0; seconds_count<=0;
            // The video reader has acknowledged its NEW buffer. Only now reuse old one.
            write_buf_idx<={1'b0,~write_buf_idx[0]};
            load_index<=(load_index==13) ? 0 : load_index+1'b1;
            load_start<=1; source_seen<=0; finish_seen<=0;
            reload_active<=0;reload_ready<=0;
            state<=LOADING;
        end
        FAILED: ; // Keep last committed picture, require K1 after correcting the card.
        default: state<=BOOT;
        endcase
    end
end
endmodule

// Four-buffer tagged cache.  Unlike the older modulo-index cache, a buffer's
// physical number is independent of its image number, so wraparound images
// (12/0, 13/1) cannot overwrite the frame currently owned by HDMI.
module playlist14_cache_safe #(
 parameter integer CLK_HZ=100000000,COVER_SECONDS=12,IMAGE_SECONDS=5
)(
 input clk,rst,catalog_ready,source_done,source_error,
 input write_finish_toggle,next_press,prev_press,auto_press,scale_change_toggle,
 input narration_enable,narration_busy,swap_ack_toggle,
 output reg load_start,output reg [3:0] load_index,output reg [1:0] write_buf_idx,
 output reg swap_toggle,output reg manual_transition_toggle,
 output reg [1:0] swap_buffer,output reg [3:0] swap_image,output reg [1:0] swap_effect,
 output reg auto_enabled,output reg [3:0] current_image,output reg display_started,
 output wire fault
);
 localparam BOOT=0,LOADING=1,READY=2,SWAPPING=3,FAILED=4;
 localparam NAV_NONE=0,NAV_NEXT=1,NAV_PREV=2;
 reg [2:0] state; reg [2:0] finish_sync,ack_sync;
 reg source_seen,finish_seen,load_for_swap,manual_wait;
 reg [1:0] nav_pending,current_buffer;
 reg [1:0] pending_effect,effect_sequence;
 reg [31:0] manual_delay_count;
 reg [31:0] seconds_div; reg [3:0] seconds_count;
 reg [3:0] cache_valid;
 reg [3:0] cache_tag0,cache_tag1,cache_tag2,cache_tag3;
 wire finished=finish_sync[2]^finish_sync[1];
 wire [3:0] next_image=(current_image==13)?4'd0:current_image+1'b1;
 wire [3:0] prev_image=(current_image==0)?4'd13:current_image-1'b1;
 wire auto_due=auto_enabled&&!auto_press&&display_started&&
  (seconds_count>=((current_image==0)?COVER_SECONDS:IMAGE_SECONDS))&&
  (!narration_enable||!narration_busy);
 assign fault=state==FAILED;

 function [2:0] cache_find;
  input [3:0] image;
  begin
   if(cache_valid[0]&&cache_tag0==image) cache_find={1'b1,2'd0};
   else if(cache_valid[1]&&cache_tag1==image) cache_find={1'b1,2'd1};
   else if(cache_valid[2]&&cache_tag2==image) cache_find={1'b1,2'd2};
   else if(cache_valid[3]&&cache_tag3==image) cache_find={1'b1,2'd3};
   else cache_find=3'b000;
  end
 endfunction
 function [1:0] victim_buffer;
  input dummy;
  begin
   // Prefer an unused buffer, then the one that is neither current nor an
   // adjacent-image cache entry.  At least one of four buffers is available.
   if(!cache_valid[0]&&current_buffer!=0) victim_buffer=0;
   else if(!cache_valid[1]&&current_buffer!=1) victim_buffer=1;
   else if(!cache_valid[2]&&current_buffer!=2) victim_buffer=2;
   else if(!cache_valid[3]&&current_buffer!=3) victim_buffer=3;
   else if(current_buffer!=0&&cache_tag0!=next_image&&cache_tag0!=prev_image) victim_buffer=0;
   else if(current_buffer!=1&&cache_tag1!=next_image&&cache_tag1!=prev_image) victim_buffer=1;
   else if(current_buffer!=2&&cache_tag2!=next_image&&cache_tag2!=prev_image) victim_buffer=2;
   else victim_buffer=3;
  end
 endfunction
 wire [2:0] next_hit=cache_find(next_image);
 wire [2:0] prev_hit=cache_find(prev_image);

 always @(posedge clk or posedge rst) begin
  if(rst) begin
   state<=BOOT;finish_sync<=0;ack_sync<=0;source_seen<=0;finish_seen<=0;load_for_swap<=0;
   nav_pending<=NAV_NONE;current_buffer<=0;manual_wait<=0;manual_delay_count<=0;
   pending_effect<=0;effect_sequence<=0;
   seconds_div<=0;seconds_count<=0;
   cache_valid<=0;cache_tag0<=0;cache_tag1<=0;cache_tag2<=0;cache_tag3<=0;
   load_start<=0;load_index<=0;write_buf_idx<=0;swap_toggle<=0;manual_transition_toggle<=0;
   swap_buffer<=0;swap_image<=0;swap_effect<=0;auto_enabled<=0;current_image<=0;display_started<=0;
  end else begin
   finish_sync<={finish_sync[1:0],write_finish_toggle};
   ack_sync<={ack_sync[1:0],swap_ack_toggle};
   load_start<=0;
   if(auto_press) begin auto_enabled<=~auto_enabled;seconds_div<=0;seconds_count<=0;end
   else if(auto_enabled&&display_started&&!auto_due) begin
    if(seconds_div==CLK_HZ-1) begin seconds_div<=0;if(seconds_count!=4'hf)seconds_count<=seconds_count+1'b1;end
    else seconds_div<=seconds_div+1'b1;
   end
   // Adjacent images are prefetched in READY.  A manual request therefore
   // commits immediately on a cache hit; on a miss it starts loading without
   // an artificial one-second delay while the current image stays unchanged.
   if(prev_press) begin
    nav_pending<=NAV_PREV;manual_wait<=0;manual_delay_count<=0;pending_effect<=effect_sequence;
    effect_sequence<=(effect_sequence==2)?0:effect_sequence+1'b1;
   end else if(next_press) begin
    nav_pending<=NAV_NEXT;manual_wait<=0;manual_delay_count<=0;pending_effect<=effect_sequence;
    effect_sequence<=(effect_sequence==2)?0:effect_sequence+1'b1;
   end
   case(state)
    BOOT:if(catalog_ready) begin
     load_index<=0;write_buf_idx<=0;load_for_swap<=1;load_start<=1;
     source_seen<=0;finish_seen<=0;state<=LOADING;
    end
    LOADING:begin
     if(source_done)source_seen<=1;
     if(finished)finish_seen<=1;
     if(source_error)state<=FAILED;
     else if((source_seen||source_done)&&(finish_seen||finished))begin
      case(write_buf_idx)
       0:begin cache_tag0<=load_index;cache_valid[0]<=1;end
       1:begin cache_tag1<=load_index;cache_valid[1]<=1;end
       2:begin cache_tag2<=load_index;cache_valid[2]<=1;end
       default:begin cache_tag3<=load_index;cache_valid[3]<=1;end
      endcase
      if(load_for_swap)begin
       swap_buffer<=write_buf_idx;swap_image<=load_index;swap_toggle<=~swap_toggle;state<=SWAPPING;
      end else state<=READY;
     end
    end
    READY:begin
     if((nav_pending==NAV_PREV)&&!manual_wait)begin
      nav_pending<=NAV_NONE;
      if(prev_hit[2])begin swap_buffer<=prev_hit[1:0];swap_image<=prev_image;swap_effect<=pending_effect;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else begin load_index<=prev_image;write_buf_idx<=victim_buffer(1'b0);load_for_swap<=1;swap_effect<=pending_effect;
       case(victim_buffer(1'b0))0:cache_valid[0]<=0;1:cache_valid[1]<=0;2:cache_valid[2]<=0;3:cache_valid[3]<=0;endcase
       load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
     end else if((nav_pending==NAV_NEXT)&&!manual_wait)begin
      nav_pending<=NAV_NONE;
      if(next_hit[2])begin swap_buffer<=next_hit[1:0];swap_image<=next_image;swap_effect<=pending_effect;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else begin load_index<=next_image;write_buf_idx<=victim_buffer(1'b0);load_for_swap<=1;swap_effect<=pending_effect;
       case(victim_buffer(1'b0))0:cache_valid[0]<=0;1:cache_valid[1]<=0;2:cache_valid[2]<=0;3:cache_valid[3]<=0;endcase
       load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
     end else if(auto_due)begin
      // Automatic navigation shares the same 0/1/2 effect sequence as
      // manual previous/next navigation instead of forcing fade every time.
      swap_effect<=effect_sequence;
      effect_sequence<=(effect_sequence==2)?0:effect_sequence+1'b1;
      if(next_hit[2])begin swap_buffer<=next_hit[1:0];swap_image<=next_image;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else begin load_index<=next_image;write_buf_idx<=victim_buffer(1'b0);load_for_swap<=1;
       case(victim_buffer(1'b0))0:cache_valid[0]<=0;1:cache_valid[1]<=0;2:cache_valid[2]<=0;3:cache_valid[3]<=0;endcase
       load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
     end else if(!next_hit[2])begin
      load_index<=next_image;write_buf_idx<=victim_buffer(1'b0);load_for_swap<=0;
      case(victim_buffer(1'b0))0:cache_valid[0]<=0;1:cache_valid[1]<=0;2:cache_valid[2]<=0;3:cache_valid[3]<=0;endcase
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end else if(!prev_hit[2])begin
      load_index<=prev_image;write_buf_idx<=victim_buffer(1'b0);load_for_swap<=0;
      case(victim_buffer(1'b0))0:cache_valid[0]<=0;1:cache_valid[1]<=0;2:cache_valid[2]<=0;3:cache_valid[3]<=0;endcase
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end
    end
    SWAPPING:if(ack_sync[2]==swap_toggle)begin
     current_image<=swap_image;current_buffer<=swap_buffer;display_started<=1;
     seconds_div<=0;seconds_count<=0;load_for_swap<=0;state<=READY;
    end
    FAILED:;
    default:state<=BOOT;
   endcase
  end
 end
endmodule

// Four-buffer adjacent-image cache. Current/previous/next images remain resident;
// the fourth buffer follows the last navigation direction for quick repeated keys.
module playlist14 #(
 parameter integer CLK_HZ=100000000,COVER_SECONDS=12,IMAGE_SECONDS=5
)(
 input clk,rst,catalog_ready,source_done,source_error,
 input write_finish_toggle,next_press,prev_press,auto_press,scale_change_toggle,
 input narration_enable,narration_busy,swap_ack_toggle,
 output reg load_start,output reg [3:0] load_index,output reg [1:0] write_buf_idx,
 output reg swap_toggle,output reg [1:0] swap_buffer,output reg [3:0] swap_image,
 output reg auto_enabled,output reg [3:0] current_image,output reg display_started,
 output wire fault
);
 localparam BOOT=0,LOADING=1,READY=2,SWAPPING=3,FAILED=4;
 localparam NAV_NONE=0,NAV_NEXT=1,NAV_PREV=2;
 reg [2:0] state;reg [2:0] finish_sync,ack_sync;
 reg source_seen,finish_seen,load_for_swap;
 reg [1:0] nav_pending,last_direction;
 reg [31:0] seconds_div;reg [3:0] seconds_count;
 reg [3:0] cache_valid;
 reg [3:0] cache_img0,cache_img1,cache_img2,cache_img3;
 wire finished=finish_sync[2]^finish_sync[1];
 reg [3:0] next_image,prev_image,next2_image,prev2_image;
 function cache_hit;input [3:0] img;begin case(img[1:0])
  0:cache_hit=cache_valid[0]&&(cache_img0==img);
  1:cache_hit=cache_valid[1]&&(cache_img1==img);
  2:cache_hit=cache_valid[2]&&(cache_img2==img);
  default:cache_hit=cache_valid[3]&&(cache_img3==img);
 endcase end endfunction
 wire auto_due=auto_enabled&&!auto_press&&display_started&&
  (seconds_count>=((current_image==0)?COVER_SECONDS:IMAGE_SECONDS))&&
  (!narration_enable||!narration_busy);
 assign fault=state==FAILED;
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   state<=BOOT;finish_sync<=0;ack_sync<=0;source_seen<=0;finish_seen<=0;load_for_swap<=0;
   nav_pending<=NAV_NONE;last_direction<=NAV_NEXT;seconds_div<=0;seconds_count<=0;
   cache_valid<=0;cache_img0<=0;cache_img1<=0;cache_img2<=0;cache_img3<=0;
   next_image<=1;prev_image<=13;next2_image<=2;prev2_image<=12;
   load_start<=0;load_index<=0;write_buf_idx<=0;swap_toggle<=0;swap_buffer<=0;swap_image<=0;
   auto_enabled<=0;current_image<=0;display_started<=0;
  end else begin
   finish_sync<={finish_sync[1:0],write_finish_toggle};ack_sync<={ack_sync[1:0],swap_ack_toggle};load_start<=0;
   if(auto_press)begin auto_enabled<=~auto_enabled;seconds_div<=0;seconds_count<=0;end
   else if(auto_enabled&&display_started&&!auto_due)begin
    if(seconds_div==CLK_HZ-1)begin seconds_div<=0;if(seconds_count!=4'hf)seconds_count<=seconds_count+1'b1;end
    else seconds_div<=seconds_div+1'b1;
   end
   if(prev_press)nav_pending<=NAV_PREV;else if(next_press)nav_pending<=NAV_NEXT;
   case(state)
    BOOT:if(catalog_ready)begin load_index<=0;write_buf_idx<=0;cache_valid[0]<=0;load_for_swap<=1;
     load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
    LOADING:begin
     if(source_done)source_seen<=1;if(finished)finish_seen<=1;
     if(source_error)state<=FAILED;
     else if((source_seen||source_done)&&(finish_seen||finished))begin
      case(write_buf_idx)
       0:begin cache_img0<=load_index;cache_valid[0]<=1;end
       1:begin cache_img1<=load_index;cache_valid[1]<=1;end
       2:begin cache_img2<=load_index;cache_valid[2]<=1;end
       default:begin cache_img3<=load_index;cache_valid[3]<=1;end
      endcase
      if(load_for_swap)begin swap_buffer<=write_buf_idx;swap_image<=load_index;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else state<=READY;
     end
    end
    READY:begin
     if((nav_pending==NAV_PREV)||prev_press)begin
      nav_pending<=NAV_NONE;last_direction<=NAV_PREV;
      if(cache_hit(prev_image))begin swap_buffer<=prev_image[1:0];swap_image<=prev_image;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else begin load_index<=prev_image;write_buf_idx<=prev_image[1:0];cache_valid[prev_image[1:0]]<=0;load_for_swap<=1;
       load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
     end else if((nav_pending==NAV_NEXT)||next_press||auto_due)begin
      nav_pending<=NAV_NONE;last_direction<=NAV_NEXT;
      if(cache_hit(next_image))begin swap_buffer<=next_image[1:0];swap_image<=next_image;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else begin load_index<=next_image;write_buf_idx<=next_image[1:0];cache_valid[next_image[1:0]]<=0;load_for_swap<=1;
       load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
     end else if(!cache_hit(next_image))begin load_index<=next_image;write_buf_idx<=next_image[1:0];cache_valid[next_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end else if(!cache_hit(prev_image))begin load_index<=prev_image;write_buf_idx<=prev_image[1:0];cache_valid[prev_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end else if((last_direction==NAV_NEXT)&&!cache_hit(next2_image))begin load_index<=next2_image;write_buf_idx<=next2_image[1:0];cache_valid[next2_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end else if((last_direction==NAV_PREV)&&!cache_hit(prev2_image))begin load_index<=prev2_image;write_buf_idx<=prev2_image[1:0];cache_valid[prev2_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
    end
    SWAPPING:if(ack_sync[2]==swap_toggle)begin
     current_image<=swap_image;display_started<=1;seconds_div<=0;seconds_count<=0;load_for_swap<=0;
     next_image<=(swap_image==13)?0:swap_image+1'b1;
     prev_image<=(swap_image==0)?13:swap_image-1'b1;
     next2_image<=(swap_image>=12)?swap_image-12:swap_image+2'd2;
     prev2_image<=(swap_image<2)?swap_image+4'd12:swap_image-2'd2;
     state<=READY;
    end
    FAILED:;
    default:state<=BOOT;
   endcase
  end
 end
endmodule
