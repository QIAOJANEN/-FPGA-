`define DATA_WIDTH 32
`define ADDR_WIDTH 21
`define DM_WIDTH 4
`define ROW_WIDTH 11
`define BA_WIDTH 2

// Parentheses are essential: macros are textual substitution, not constants.
// 50MHz -> 20ns. The vendor timer counts 0..terminal inclusive: use terminal
// 1561 for 1562 clocks/request, so 2048 periods take 63.97952ms (less than 64ms).
`define SDR_CLK_PERIOD (1000000000 / 50000000)
`define SELF_REFRESH_INTERVAL ((64000000 / (`SDR_CLK_PERIOD) / (2 ** (`ROW_WIDTH))) - 1)
