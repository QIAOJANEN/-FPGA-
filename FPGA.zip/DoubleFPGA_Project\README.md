# 双 FPGA 智慧博物馆导览系统 · 工程源码

两块安路 **HX4S20C**（EG4S20BG256）实验板组成的主从多媒体导览工程：主板负责 SD 卡读图、BMP 解析与缩放、SDRAM 四帧缓存、字幕/频谱/转场叠加与 HDMI 输出；从板负责背景音乐与逐图讲解的读取、混音与 I2S 回传。

- 全部逻辑为 Verilog RTL，无 MCU、无软核。
- 开发环境：**Tang Dynasty 6.2（6.2.168116）**，器件 `EG4S20BG256`。

---

## 1. 目录说明

```
master/src/td_project/DoubleFPGA_Master.al   主板工程（TD 工程文件）
slave/src/td_project/DoubleFPGA_Slave.al     从板工程（TD 工程文件）
master/src|slave/src/narration|link|audio_spectrum|transition   自定义 RTL
master/src|slave/src/user_source/            厂商例程、加密 IP、SD 驱动、约束
output/DoubleFPGA_Master.bit                 预编译主板 bit（690,152 B）
output/DoubleFPGA_Slave.bit                  预编译从板 bit（629,624 B）
output/BUILD_REPORT.md                       构建摘要（SHA-256、WNS）
build_all.ps1                                一键构建（先从板、再主板）
```

## 2. 用 TD 打开与编译

1. 打开 Tang Dynasty 6.2；
2. `File → Open Project` 选择 `master/src/td_project/DoubleFPGA_Master.al`（从板同理）；
3. 首次打开若提示找不到源文件，确认整个 `master`（或 `slave`）目录是一起拷贝过来的——工程内部的源文件路径都是相对路径；
4. 直接 `Run` 即可完成综合、布局布线并生成 bit。

命令行方式（推荐，可复现）：

```powershell
.\build_all.ps1
# 工具不在默认位置时：
.\build_all.ps1 -TdCommand "C:\Anlogic\TD_6.2.1_Engineer_6.2.168.116\bin\td_commands_prompt.exe"
```

> 注意：TD 的 `td_commands_prompt.exe` 不接受**含空格或中文**的脚本路径，`build_all.ps1` 已自动把 tcl 复制到临时目录规避；但**仍然建议把本工程放在无空格、纯英文的路径下**（例如 `D:\work\DoubleFPGA_Project`）。

## 3. 烧录顺序

| 顺序 | 板卡 | 文件 |
|---|---|---|
| 1 | 从板（音频板） | `output/DoubleFPGA_Slave.bit` |
| 2 | 主板（显示/控制板） | `output/DoubleFPGA_Master.bit` |

也可在 TD 中打开对应工程重新编译后下载。两个 bit 必须来自同一次构建。

## 4. 板间接线

用 **40 芯彩虹排线**连接两板 J1，实际只用 6 芯：

| J1 引脚 | 信号 | 方向 |
|---|---|---|
| J1-2 | 正向控制 UART（1 Mbaud） | 主 → 从 |
| J1-3 | I2S BCLK（64 fs） | 从 → 主 |
| J1-4 | I2S LRCK | 从 → 主 |
| J1-5 | I2S DATA | 从 → 主 |
| J1-6 | 反向状态 UART（115200，复用原 busy 线） | 从 → 主 |
| J1-12 | GND | 公共地 |

- 排线中 **3.3 V 与 5 V 电源芯已剪除**，两板各自独立供电，**不要互接 3V3/5V**，只共地；
- 建议线长 **≤ 20 cm**，不支持热插拔，插拔时先断电；
- 全部信号为 3.3 V LVCMOS。

## 5. SD 卡准备

**主板卡（FAT32）**：根目录放 `00.BMP` ~ `13.BMP`

- 24 位、无压缩（BI_RGB）、正高度（bottom-up）BMP；
- 允许不同分辨率（宽 1~2048、高 1~4095），主板硬件缩放到 640×480。

**从板卡（FAT32）**：根目录放

```
BGM.PCM        循环背景音乐
N00.PCM ~ N13.PCM   逐图讲解
```

- 48 kHz、双声道、16 bit 有符号小端、**无文件头**。

## 6. 操作

- 主板：`KEY1` 复位，`K2` 下一张，`K3` 自动轮播开关，`K4` 上一张；`SW2` 亮度/对比度模式，`SW3` 原图分辨率提示，`SW4` 整机总开关（ON 为运行）。
- 从板：`SW1` 开关 HDMI 画面上的频谱柱，`SW2` 开关背景音乐（讲解不受影响）。

## 7. 说明

- 首次在 TD 中打开工程时可能提示一条 `PRJ-7002 ... the IP's generated file ... doesn't exist` 的 warning，这是安路工具对某个 IP 记录的路径提示，**不影响综合与烧录**（原始工程同样存在），随后的 `Successfully analyzed N source files` 即表示工程加载正常；
- 主板保留了原始 SDRAM 工程的局部时钟 critical warning，但 Setup/Hold 均收敛、失败端点为 0；
- `master/src/user_source/hdl_source/` 下的 `*.enc.v` 与 HDMI core 为安路提供的加密 IP，仅供本工程使用，**请勿再分发**。
