// Decode the periodic status byte returned over the former busy wire.
module master_status_uart_rx #(parameter integer CLK_HZ=50000000,BAUD=115200)(
 input clk,input rst,input rx,
 output reg audio_busy,output reg spectrum_enable,output reg bgm_enable,output reg status_valid);
 localparam integer CLKS_PER_BIT=CLK_HZ/BAUD;
 localparam IDLE=0,START=1,DATA=2,STOP=3;
 reg [1:0] rx_sync;
 reg [1:0] state;
 reg [15:0] baud_count;
 reg [2:0] bit_index;
 reg [7:0] data_shift;
 reg [24:0] watchdog;
 always @(posedge clk or posedge rst)begin
  if(rst)begin rx_sync<=2'b11;state<=IDLE;baud_count<=0;bit_index<=0;data_shift<=0;
   audio_busy<=1;spectrum_enable<=1;bgm_enable<=1;status_valid<=0;watchdog<=0;end
  else begin
   rx_sync<={rx_sync[0],rx};
   if(watchdog<25'd25000000)watchdog<=watchdog+1'b1;
   else begin audio_busy<=1;status_valid<=0;end
   case(state)
    IDLE:if(!rx_sync[1])begin baud_count<=0;state<=START;end
    START:if(baud_count==CLKS_PER_BIT/2)begin
     baud_count<=0;
     if(!rx_sync[1])begin bit_index<=0;state<=DATA;end else state<=IDLE;
    end else baud_count<=baud_count+1'b1;
    DATA:if(baud_count==CLKS_PER_BIT-1)begin
     baud_count<=0;data_shift[bit_index]<=rx_sync[1];
     if(bit_index==7)state<=STOP;else bit_index<=bit_index+1'b1;
    end else baud_count<=baud_count+1'b1;
    STOP:if(baud_count==CLKS_PER_BIT-1)begin
     baud_count<=0;state<=IDLE;
     if(rx_sync[1]&&data_shift[7:3]==5'b10100)begin
      bgm_enable<=data_shift[2];spectrum_enable<=data_shift[1];audio_busy<=data_shift[0];
      status_valid<=1;watchdog<=0;
     end
    end else baud_count<=baud_count+1'b1;
    default:state<=IDLE;
   endcase
  end
 end
endmodule
