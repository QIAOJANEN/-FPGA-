// Repeated 8N1 control frame, 1 Mbaud from the 50 MHz board clock.
// Payload: 1,1,enable,image[3:0],parity.
module master_control_uart_tx #(
    parameter integer CLK_HZ = 50_000_000,
    parameter integer BAUD   = 1_000_000
)(
    input  wire       clk,
    input  wire       rst,
    input  wire       narration_enable,
    input  wire [3:0] image_index,
    output reg        tx
);
    localparam integer DIV = CLK_HZ / BAUD;
    localparam integer GAP = CLK_HZ / 1000; // refresh once per millisecond
    reg [15:0] baud_count;
    reg [15:0] gap_count;
    reg [3:0]  bit_index;
    reg [9:0]  frame;
    reg        busy;
    wire [7:0] payload = {2'b11,narration_enable,image_index,^({2'b11,narration_enable,image_index})};

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            tx <= 1'b1; baud_count <= 0; gap_count <= 0;
            bit_index <= 0; frame <= 10'h3ff; busy <= 1'b0;
        end else if (!busy) begin
            tx <= 1'b1;
            if (gap_count == GAP-1) begin
                gap_count <= 0; frame <= {1'b1,payload,1'b0};
                bit_index <= 0; baud_count <= 0; busy <= 1'b1; tx <= 1'b0;
            end else gap_count <= gap_count + 1'b1;
        end else if (baud_count == DIV-1) begin
            baud_count <= 0;
            if (bit_index == 9) begin busy <= 1'b0; tx <= 1'b1; end
            else begin bit_index <= bit_index + 1'b1; tx <= frame[bit_index+1'b1]; end
        end else baud_count <= baud_count + 1'b1;
    end
endmodule
