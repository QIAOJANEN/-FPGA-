// 64-bit slots, 24-bit MSB-aligned, matching the project's I2S_receiver.
module pcm_i2s_64fs_tx(
 input wire mclk,input wire rst,input wire [23:0] left_sample,right_sample,
 output reg bclk,output reg lrck,output reg data
);
 reg [5:0] bit_count; reg [63:0] shift_reg; reg [23:0] left_hold,right_hold;
 always @(posedge mclk or posedge rst) begin
  if(rst) begin bclk<=0;lrck<=0;data<=0;bit_count<=0;shift_reg<=0;left_hold<=0;right_hold<=0;end
  else begin
   bclk<=~bclk;
   if(bclk) begin
    data<=shift_reg[63]; shift_reg<={shift_reg[62:0],1'b0};
    if(bit_count==63) begin
     bit_count<=0;
     if(!lrck) begin lrck<=1;shift_reg<={right_hold,40'd0};end
     else begin lrck<=0;left_hold<=left_sample;right_hold<=right_sample;shift_reg<={left_sample,40'd0};end
    end else bit_count<=bit_count+1'b1;
   end
  end
 end
endmodule
