// 640x480 source-frame scaler used before the SDRAM write FIFO.
// It preserves the 640x480 framebuffer size and centers a nearest-neighbour
// 90/80/70/60-percent image on a dark background. Two 640-pixel line buffers
// decouple the sparse SPI pixel stream from the generated output stream.
module bmp_frame_scaler(
 input clk,input rst,input scale_enable,input [2:0] scale_level,
 input write_req,input write_req_ack,input downstream_ready,
 input source_we,input [23:0] source_data,
 output source_sector_ready,output out_we,output [23:0] out_data);
 reg ack_d,active;
 reg [9:0] target_w,target_h,left;
 reg [16:0] top_pixels;
 reg wr_sel,pending_sel,line_pending,source_complete;
 reg [9:0] in_x,in_y;
 reg [10:0] v_acc;
 reg [9:0] h_src,out_x;
 reg [10:0] h_acc;
 reg [18:0] out_count;
 reg [2:0] ost;
 reg scaled_we;reg [23:0] scaled_data;
 localparam O_TOP=0,O_IDLE=1,O_LINE=2,O_PIXEL=3,O_BOTTOM=4,O_DONE=5;
 wire frame_start=write_req_ack&&!ack_d;
 wire select_row=(v_acc+target_h>=480);
 wire line0_we=source_we&&active&&!wr_sel;
 wire line1_we=source_we&&active&& wr_sel;
 wire [23:0] line0_q,line1_q;
 wire [23:0] rd_data=pending_sel?line1_q:line0_q;
 assign source_sector_ready=active ? (ost!=O_TOP && !source_complete && !line_pending) : downstream_ready;
 assign out_we=active ? scaled_we : source_we;
 assign out_data=active ? scaled_data : source_data;

 // Explicit block-RAM line stores.  The force_ram attribute in this existing
 // TD inference wrapper is important on EG4S20: an unpacked array here may be
 // expanded into MSlices and make physical implementation exceed the device.
 ram_infer_wfifo_32_32_512 #(
  .MODE("SDP"),.DATAWIDTH_A(24),.ADDRWIDTH_A(10),.DATADEPTH_A(640),
  .DATAWIDTH_B(24),.ADDRWIDTH_B(10),.DATADEPTH_B(640),
  .REGMODE_A("NOREG"),.REGMODE_B("NOREG")) u_scale_line0(
  .clka(clk),.rsta(rst),.cea(1'b1),.ocea(1'b1),.wea(line0_we),
  .dia(source_data),.addra(in_x),.doa(),
  .clkb(clk),.rstb(rst),.ceb(1'b1),.oceb(1'b1),.web(1'b0),
  .dib(24'b0),.addrb(h_src),.dob(line0_q));
 ram_infer_wfifo_32_32_512 #(
  .MODE("SDP"),.DATAWIDTH_A(24),.ADDRWIDTH_A(10),.DATADEPTH_A(640),
  .DATAWIDTH_B(24),.ADDRWIDTH_B(10),.DATADEPTH_B(640),
  .REGMODE_A("NOREG"),.REGMODE_B("NOREG")) u_scale_line1(
  .clka(clk),.rsta(rst),.cea(1'b1),.ocea(1'b1),.wea(line1_we),
  .dia(source_data),.addra(in_x),.doa(),
  .clkb(clk),.rstb(rst),.ceb(1'b1),.oceb(1'b1),.web(1'b0),
  .dib(24'b0),.addrb(h_src),.dob(line1_q));

 always @(posedge clk or posedge rst)begin
  if(rst)begin
   ack_d<=0;active<=0;target_w<=640;target_h<=480;left<=0;top_pixels<=0;
   wr_sel<=0;pending_sel<=0;line_pending<=0;source_complete<=0;
   in_x<=0;in_y<=0;v_acc<=0;h_src<=0;out_x<=0;h_acc<=0;
   out_count<=0;ost<=O_DONE;scaled_we<=0;scaled_data<=0;
  end else begin
   ack_d<=write_req_ack;scaled_we<=0;
   if(frame_start)begin
    active<=scale_enable&&(scale_level!=0);
    case(scale_level)
     1:begin target_w<=576;target_h<=432;left<=32;top_pixels<=15360;end
     2:begin target_w<=512;target_h<=384;left<=64;top_pixels<=30720;end
     3:begin target_w<=448;target_h<=336;left<=96;top_pixels<=46080;end
     default:begin target_w<=384;target_h<=288;left<=128;top_pixels<=61440;end
    endcase
    wr_sel<=0;line_pending<=0;source_complete<=0;in_x<=0;in_y<=0;v_acc<=0;
    h_src<=0;out_x<=0;h_acc<=0;out_count<=0;
    ost<=(scale_enable&&(scale_level!=0))?O_TOP:O_DONE;
   end else if(active)begin
    // Capture the incoming 640x480 BMP pixels. SPI delivers pixels much more
    // slowly than a generated output line, so ping-pong lines are sufficient.
    if(source_we)begin
     if(in_x==639)begin
      in_x<=0;
      if(select_row)begin
       v_acc<=v_acc+target_h-480;
       pending_sel<=wr_sel;line_pending<=1;wr_sel<=~wr_sel;
      end else v_acc<=v_acc+target_h;
      if(in_y==479)source_complete<=1;else in_y<=in_y+1'b1;
     end else in_x<=in_x+1'b1;
    end

    case(ost)
     O_TOP:if(downstream_ready)begin
      scaled_we<=1;scaled_data<=24'h081020;out_count<=out_count+1'b1;
      if(out_count+1'b1>=top_pixels)ost<=O_IDLE;
     end
     O_IDLE:begin
      if(line_pending)begin line_pending<=0;out_x<=0;h_src<=0;h_acc<=0;ost<=O_LINE;end
      else if(source_complete)ost<=O_BOTTOM;
     end
     O_LINE:if(downstream_ready)begin
      if(out_x<left || out_x>=left+target_w)begin
       scaled_we<=1;scaled_data<=24'h081020;out_count<=out_count+1'b1;
       if(out_x==639)ost<=source_complete&&!line_pending?O_BOTTOM:O_IDLE;
       else out_x<=out_x+1'b1;
      end else ost<=O_PIXEL; // rd_data is registered from h_src
     end
     O_PIXEL:if(downstream_ready)begin
      scaled_we<=1;scaled_data<=rd_data;out_count<=out_count+1'b1;
      if(h_acc+640>=({1'b0,target_w}<<1))begin h_acc<=h_acc+640-({1'b0,target_w}<<1);h_src<=h_src+2;end
      else begin h_acc<=h_acc+640-target_w;h_src<=h_src+1'b1;end
      if(out_x==639)ost<=source_complete&&!line_pending?O_BOTTOM:O_IDLE;
      else begin out_x<=out_x+1'b1;ost<=O_LINE;end
     end
     O_BOTTOM:if(downstream_ready)begin
      scaled_we<=1;scaled_data<=24'h081020;
      if(out_count==307199)ost<=O_DONE;
      else out_count<=out_count+1'b1;
     end
     default:;
    endcase
   end
  end
 end
endmodule
