// Picture-only SD path.  Audio files are intentionally never requested on
// the master board, so its card may contain only the BMP/FAT image set.
module sd_card_picture_master #(parameter integer CLK_FREQ_HZ=100000000)(
 input clk,rst,key_next,key_auto,key_prev,
 input narration_enable,input narration_busy,input [3:0] narration_image,input narration_play_toggle,
 input scale_enable,input [2:0] scale_level,input scale_change_toggle,
 output [3:0] state_code,input write_finish_toggle,write_sector_ready,swap_ack_toggle,
 output swap_toggle,output manual_transition_toggle,output [1:0] swap_buffer,output [3:0] swap_image,output [1:0] swap_effect,output [1:0] write_buf_idx,
 output write_req,input write_req_ack,output write_en,output [31:0] write_data,
 output SD_nCS,SD_DCLK,SD_MOSI,input SD_MISO);
 wire next_press,auto_press,prev_press,sd_init_done,sec_read,sec_valid,sec_end;
 wire [31:0] sec_address; wire [7:0] sec_data;
 wire catalog_ready,load_start,load_done,reader_error,playlist_error; wire [3:0] load_index,reader_state;
 wire [23:0] rgb,raw_rgb; wire raw_write_en,source_sector_ready;
 wire [11:0] source_width,source_height;
 assign write_data={rgb,8'b0};
 assign state_code=reader_error?reader_state:playlist_error?4'hf:reader_state;
 key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(10)) u_kn(.clk(clk),.rst(rst),.button_in(key_next),.press_pulse(next_press));
 key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(10)) u_ka(.clk(clk),.rst(rst),.button_in(key_auto),.press_pulse(auto_press));
 key_press_debounce #(.CLK_FREQ_HZ(CLK_FREQ_HZ),.DEBOUNCE_MS(10)) u_kp(.clk(clk),.rst(rst),.button_in(key_prev),.press_pulse(prev_press));
 // Four tagged frame buffers retain the displayed image and prefetch both
 // adjacent images without ever overwriting the buffer owned by HDMI.
 playlist14_cache_safe #(.CLK_HZ(CLK_FREQ_HZ),.COVER_SECONDS(8),.IMAGE_SECONDS(7)) u_playlist(
  .clk(clk),.rst(rst),.catalog_ready(catalog_ready),.source_done(load_done),.source_error(reader_error),
  .write_finish_toggle(write_finish_toggle),.next_press(next_press),.prev_press(prev_press),.auto_press(auto_press),.scale_change_toggle(scale_change_toggle),
  .narration_enable(narration_enable),.narration_busy(narration_busy),.swap_ack_toggle(swap_ack_toggle),.load_start(load_start),.load_index(load_index),
  .write_buf_idx(write_buf_idx),.swap_toggle(swap_toggle),.manual_transition_toggle(manual_transition_toggle),
  .swap_buffer(swap_buffer),.swap_image(swap_image),.swap_effect(swap_effect),.auto_enabled(),.current_image(),.display_started(),.fault(playlist_error));
 bmp_read u_bmp(.clk(clk),.rst(rst),.sd_init_done(sd_init_done),.catalog_ready(catalog_ready),.found_mask(),.load_start(load_start),.load_index(load_index),
  .load_done(load_done),.error(reader_error),.state_code(reader_state),.write_req(write_req),.write_req_ack(write_req_ack),.write_sector_ready(source_sector_ready),
  .sd_sec_read(sec_read),.sd_sec_read_addr(sec_address),.sd_sec_read_data(sec_data),.sd_sec_read_data_valid(sec_valid),.sd_sec_read_end(sec_end),.bmp_data_wr_en(raw_write_en),.bmp_data(raw_rgb),
  .source_width(source_width),.source_height(source_height));
 bmp_frame_scaler u_frame_scaler(.clk(clk),.rst(rst),.scale_enable(scale_enable),.scale_level(scale_level),
  .source_width(source_width),.source_height(source_height),.write_req(write_req),.write_req_ack(write_req_ack),
  .downstream_ready(write_sector_ready),.source_we(raw_write_en),.source_data(raw_rgb),.source_sector_ready(source_sector_ready),.out_we(write_en),.out_data(rgb));
 sd_card_top u_sd(.clk(clk),.rst(rst),.SD_nCS(SD_nCS),.SD_DCLK(SD_DCLK),.SD_MOSI(SD_MOSI),.SD_MISO(SD_MISO),.sd_init_done(sd_init_done),.sd_sec_read(sec_read),
  .sd_sec_read_addr(sec_address),.sd_sec_read_data(sec_data),.sd_sec_read_data_valid(sec_valid),.sd_sec_read_end(sec_end),.sd_sec_write(1'b0),.sd_sec_write_addr(32'd0),
  .sd_sec_write_data(),.sd_sec_write_data_req(),.sd_sec_write_end());
endmodule
