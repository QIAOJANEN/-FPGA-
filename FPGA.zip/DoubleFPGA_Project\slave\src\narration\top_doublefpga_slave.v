module top(
 input clk,input rst_n,input sw1,input sw2,input link_cmd_rx,
 output link_i2s_bclk,output link_i2s_lrck,output link_i2s_data,
 output link_audio_busy,
 output sd_ncs,output sd_dclk,output sd_mosi,input sd_miso,
 output [3:0] status_led
);
 wire sd_card_clk,audio_mclk,pll_lock;wire rst=~rst_n|~pll_lock;
 wire narration_enable,command_toggle;wire [3:0] image_index,state_code;
 wire [23:0] audio_left,audio_right;wire audio_toggle;
 wire audio_busy_raw;
 reg sw1_meta,sw1_sync,sw2_meta,sw2_sync;
 reg audio_busy_meta,audio_busy_sync;
 wire spectrum_enable=~sw1_sync;
 wire bgm_enable=~sw2_sync;
 always @(posedge clk or posedge rst) begin
  if(rst)begin
   sw1_meta<=1'b1;sw1_sync<=1'b1;sw2_meta<=1'b1;sw2_sync<=1'b1;
   audio_busy_meta<=1'b1;audio_busy_sync<=1'b1;
  end else begin
   sw1_meta<=sw1;sw1_sync<=sw1_meta;sw2_meta<=sw2;sw2_sync<=sw2_meta;
   audio_busy_meta<=audio_busy_raw;audio_busy_sync<=audio_busy_meta;
  end
 end
 sys_pll u_sys_pll(.refclk(clk),.clk0_out(sd_card_clk),.clk1_out(),.clk2_out(),.reset(1'b0));
 PLL_HDMI_AUDIO u_audio_pll(.refclk(clk),.reset(1'b0),.extlock(pll_lock),.clk0_out(),.clk1_out(),.clk2_out(audio_mclk));
 slave_control_uart_rx u_control(.clk(clk),.rst(rst),.rx(link_cmd_rx),.narration_enable(narration_enable),.image_index(image_index),.command_toggle(command_toggle));
 audio_storage_slave u_audio(.clk(sd_card_clk),.audio_mclk(audio_mclk),.rst(rst),.narration_enable(narration_enable),.image_index(image_index),.command_toggle(command_toggle),.bgm_enable(bgm_enable),
  .audio_left(audio_left),.audio_right(audio_right),.audio_toggle(audio_toggle),.audio_busy(audio_busy_raw),
  .SD_nCS(sd_ncs),.SD_DCLK(sd_dclk),.SD_MOSI(sd_mosi),.SD_MISO(sd_miso),.state_code(state_code));
 pcm_i2s_64fs_tx u_i2s(.mclk(audio_mclk),.rst(rst),.left_sample(audio_left),.right_sample(audio_right),.bclk(link_i2s_bclk),.lrck(link_i2s_lrck),.data(link_i2s_data));
 slave_status_uart_tx u_status(.clk(clk),.rst(rst),.audio_busy(audio_busy_sync),.spectrum_enable(spectrum_enable),.bgm_enable(bgm_enable),.tx(link_audio_busy));
 assign status_led=~state_code;
endmodule
