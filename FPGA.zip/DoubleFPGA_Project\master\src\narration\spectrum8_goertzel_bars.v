// Eight real Goertzel bins rendered as sixteen paired bars.
// This keeps useful audio visualization while reducing the dynamic mux fabric.
module spectrum8_goertzel_bars(input clk,input rst,input sample_valid,input signed [23:0] sample,output reg [111:0] levels);
 reg signed [31:0] s1[0:7];reg signed [31:0] s2[0:7];reg signed [31:0] x;reg [2:0] band;reg [8:0] count;reg busy;integer i;
 reg signed [15:0] coeff;wire signed [47:0] product=coeff*s1[band];wire signed [47:0] accum=(x<<<14)+product-(s2[band]<<<14);
 wire signed [31:0] s0=accum>>>14;wire [32:0] magnitude=(s0[31]?(~s0+1'b1):s0)+(s1[band][31]?(~s1[band]+1'b1):s1[band]);
 reg [6:0] target,old_level,new_level;
 always @* begin
  case(band)0:coeff=16'sd32766;1:coeff=16'sd32729;2:coeff=16'sd32610;3:coeff=16'sd32214;4:coeff=16'sd30715;5:coeff=16'sd25583;6:coeff=16'sd11039;default:coeff=-16'sd25330;endcase
  if(magnitude[32:25]!=0)target=100;else if(magnitude[24])target=94;else if(magnitude[23])target=88;else if(magnitude[22])target=82;
  else if(magnitude[21])target=76;else if(magnitude[20])target=70;else if(magnitude[19])target=64;else if(magnitude[18])target=58;
  else if(magnitude[17])target=52;else if(magnitude[16])target=46;else if(magnitude[15])target=40;else if(magnitude[14])target=34;
  else if(magnitude[13])target=28;else if(magnitude[12])target=22;else if(magnitude[11])target=16;else if(magnitude[10])target=10;else target=0;
  case(band)0:old_level=levels[6:0];1:old_level=levels[20:14];2:old_level=levels[34:28];3:old_level=levels[48:42];
   4:old_level=levels[62:56];5:old_level=levels[76:70];6:old_level=levels[90:84];default:old_level=levels[104:98];endcase
  if(target>old_level)new_level=target;else if(old_level>2)new_level=old_level-2;else new_level=0;
 end
 always @(posedge clk or posedge rst)begin
  if(rst)begin levels<=0;band<=0;count<=0;busy<=0;x<=0;for(i=0;i<8;i=i+1)begin s1[i]<=0;s2[i]<=0;end end
  else begin
   if(sample_valid&&!busy)begin x<={{16{sample[23]}},sample[23:8]};band<=0;busy<=1;end
   else if(busy)begin
    if(count==511)begin
     case(band)
      0:levels[13:0]<={new_level,new_level};1:levels[27:14]<={new_level,new_level};2:levels[41:28]<={new_level,new_level};3:levels[55:42]<={new_level,new_level};
      4:levels[69:56]<={new_level,new_level};5:levels[83:70]<={new_level,new_level};6:levels[97:84]<={new_level,new_level};7:levels[111:98]<={new_level,new_level};endcase
     s1[band]<=0;s2[band]<=0;
    end else begin s2[band]<=s1[band];s1[band]<=s0;end
    if(band==7)begin band<=0;busy<=0;if(count==511)count<=0;else count<=count+1'b1;end else band<=band+1'b1;
   end
  end
 end
endmodule
