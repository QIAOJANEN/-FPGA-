// CDC mailbox: switch only at the vertical-blank frame request. Acknowledge
// only after the SDRAM reader has drained old reads and latched the new base.
module display_swap(
    input clk, rst,
    input frame_req,
    output frame_ack,
    output reg memory_req,
    input memory_ack,
    input swap_toggle,
    input [1:0] swap_buffer,
    input [3:0] swap_image,
    output reg ack_toggle,
    output reg [1:0] display_buffer,
    output reg [3:0] display_image,
    output reg display_valid
);
reg [2:0] request_sync;
reg [1:0] ack_sync;
reg [1:0] buffer_meta, buffer_sync;
reg [3:0] image_meta, image_sync;
reg [2:0] state;
reg [2:0] guard_count;
reg transaction_swap, transaction_token;
assign frame_ack = (state == 3);
always @(posedge clk or posedge rst) begin
    if (rst) begin
        request_sync<=0; ack_sync<=0; buffer_meta<=0; buffer_sync<=0;
        image_meta<=0; image_sync<=0; state<=0; guard_count<=0;
        transaction_swap<=0; transaction_token<=0;
        memory_req<=0; ack_toggle<=0; display_buffer<=0;
        display_image<=0; display_valid<=0;
    end else begin
        request_sync<={request_sync[1:0],swap_toggle};
        ack_sync<={ack_sync[0],memory_ack};
        buffer_meta<=swap_buffer; buffer_sync<=buffer_meta;
        image_meta<=swap_image; image_sync<=image_meta;
        case (state)
        0: if (frame_req && !ack_sync[1]) begin
            transaction_swap <= request_sync[2] != ack_toggle;
            transaction_token <= request_sync[2];
            if (request_sync[2] != ack_toggle) begin
                display_buffer<=buffer_sync; display_image<=image_sync;
            end
            guard_count<=0; state<=1;
        end
        1: if (guard_count == 4) begin memory_req<=1; state<=2; end
           else guard_count<=guard_count+1'b1;
        2: if (ack_sync[1]) begin
            memory_req<=0;
            if (transaction_swap) begin
                ack_toggle<=transaction_token; display_valid<=1;
            end
            state<=3;
        end
        3: if (!frame_req && !ack_sync[1]) state<=0;
        default: state<=0;
        endcase
    end
end
endmodule
