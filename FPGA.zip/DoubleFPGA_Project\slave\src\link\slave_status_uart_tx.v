// Periodic slave-to-master status UART on the former busy wire.
// Frame: 0xA0 | {BGM enable, spectrum enable, narration busy}.
module slave_status_uart_tx #(
 parameter integer CLK_HZ=50000000,
 parameter integer BAUD=115200,
 parameter integer REFRESH_BITS=16
)(input clk,input rst,input audio_busy,input spectrum_enable,input bgm_enable,output reg tx);
 localparam integer CLKS_PER_BIT=CLK_HZ/BAUD;
 reg [15:0] baud_count;
 reg [REFRESH_BITS-1:0] refresh_count;
 reg [3:0] bit_index;
 reg [7:0] data_latched;
 reg busy;
 wire [7:0] payload={4'hA,1'b0,bgm_enable,spectrum_enable,audio_busy};
 always @(posedge clk or posedge rst)begin
  if(rst)begin tx<=1;baud_count<=0;refresh_count<=0;bit_index<=0;data_latched<=0;busy<=0;end
  else if(!busy)begin
   tx<=1;refresh_count<=refresh_count+1'b1;
   if(&refresh_count)begin data_latched<=payload;busy<=1;bit_index<=0;baud_count<=0;tx<=0;end
  end else if(baud_count==CLKS_PER_BIT-1)begin
   baud_count<=0;
   if(bit_index<8)begin tx<=data_latched[bit_index];bit_index<=bit_index+1'b1;end
   else if(bit_index==8)begin tx<=1;bit_index<=9;end
   else begin tx<=1;busy<=0;end
  end else baud_count<=baud_count+1'b1;
 end
endmodule
