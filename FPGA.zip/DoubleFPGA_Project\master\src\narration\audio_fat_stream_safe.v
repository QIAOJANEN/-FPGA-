// FAT32 reader for the root file BGM.PCM. The file is raw 48 kHz stereo PCM16 LE.
module audio_fat_stream #(parameter FIFO_AW=11)(
 input clk,rst,sd_init_done,
 output reg sec_req,output reg [31:0] sec_addr,input [7:0] sec_data,input sec_valid,input sec_end,
 output reg fifo_we,output reg [31:0] fifo_din,input fifo_full,input [FIFO_AW:0] fifo_used,
 output reg ready,output reg error,output reg [3:0] state_code);
 localparam WAIT=0,BOOT_REQ=1,BOOT=2,ROOT_MAP=3,DIR_REQ=4,DIR=5,FAT_REQ=6,FAT=7,
            PLAY_MAP=8,PLAY_WAIT=9,PLAY_REQ=10,PLAY=11,FAIL=15;
 reg [3:0] st,ret;
 reg [8:0] off; reg [4:0] entoff; reg [31:0] part_lba,mbr_lba,total32,fat_size,root_cluster;
 reg [15:0] bps,reserved,signature;reg [7:0] spc,fats;reg [3:0] spc_shift;
 reg [31:0] fat_base,data_base,cluster_count,current_cluster,sector_lba;
 reg [7:0] sector_in_cluster;reg [8:0] fat_off;reg [31:0] fat_value;
 reg name_match;reg [7:0] attr;reg [31:0] entry_cluster,entry_size,start_cluster,file_size,remaining;
 reg [1:0] pack_phase;reg [23:0] pack;reg found;
 wire [31:0] next_cluster={4'b0,fat_value[27:0]};
 wire [31:0] cluster_lba=data_base+((current_cluster-2)<<spc_shift);
 // Keep 32 words free beyond one 128-word sector to avoid async FIFO pointer-edge overflow.
 wire space_sector=(fifo_used<=((1<<FIFO_AW)-160));
 always @(posedge clk or posedge rst) begin
  if(rst) begin st<=WAIT;ret<=0;sec_req<=0;sec_addr<=0;fifo_we<=0;fifo_din<=0;ready<=0;error<=0;state_code<=0;
   off<=0;entoff<=0;part_lba<=0;mbr_lba<=0;total32<=0;fat_size<=0;root_cluster<=0;bps<=0;reserved<=0;signature<=0;
   spc<=0;fats<=0;spc_shift<=0;fat_base<=0;data_base<=0;cluster_count<=0;current_cluster<=0;sector_lba<=0;
   sector_in_cluster<=0;fat_off<=0;fat_value<=0;name_match<=0;attr<=0;entry_cluster<=0;entry_size<=0;
   start_cluster<=0;file_size<=0;remaining<=0;pack_phase<=0;pack<=0;found<=0;
  end else begin
   fifo_we<=0;entoff<=off[4:0];state_code<=st;
   case(st)
    WAIT:if(sd_init_done) st<=BOOT_REQ;
    BOOT_REQ:begin sec_addr<=part_lba;sec_req<=1;off<=0;signature<=0;bps<=0;reserved<=0;spc<=0;fats<=0;fat_size<=0;root_cluster<=0;total32<=0;st<=BOOT;end
    BOOT:begin
     if(sec_valid) begin
      case(off)
       11'h00b:bps[7:0]<=sec_data;11'h00c:bps[15:8]<=sec_data;11'h00d:spc<=sec_data;
       11'h00e:reserved[7:0]<=sec_data;11'h00f:reserved[15:8]<=sec_data;11'h010:fats<=sec_data;
       11'h020:total32[7:0]<=sec_data;11'h021:total32[15:8]<=sec_data;11'h022:total32[23:16]<=sec_data;11'h023:total32[31:24]<=sec_data;
       11'h024:fat_size[7:0]<=sec_data;11'h025:fat_size[15:8]<=sec_data;11'h026:fat_size[23:16]<=sec_data;11'h027:fat_size[31:24]<=sec_data;
       11'h02c:root_cluster[7:0]<=sec_data;11'h02d:root_cluster[15:8]<=sec_data;11'h02e:root_cluster[23:16]<=sec_data;11'h02f:root_cluster[31:24]<=sec_data;
       11'h1c6:mbr_lba[7:0]<=sec_data;11'h1c7:mbr_lba[15:8]<=sec_data;11'h1c8:mbr_lba[23:16]<=sec_data;11'h1c9:mbr_lba[31:24]<=sec_data;
       11'h1fe:signature[7:0]<=sec_data;11'h1ff:signature[15:8]<=sec_data;
      endcase off<=off+1'b1;
     end
     if(sec_end) begin sec_req<=0;
      if(signature==16'haa55&&bps==512&&fat_size!=0&&root_cluster>=2) begin
       case(spc) 1:spc_shift<=0;2:spc_shift<=1;4:spc_shift<=2;8:spc_shift<=3;16:spc_shift<=4;32:spc_shift<=5;64:spc_shift<=6;128:spc_shift<=7;default:begin error<=1;st<=FAIL;end endcase
       fat_base<=part_lba+reserved;data_base<=part_lba+reserved+fat_size*fats;cluster_count<=(total32-reserved-fat_size*fats)>>spc_shift;
       current_cluster<=root_cluster;ret<=DIR_REQ;st<=ROOT_MAP;
      end else if(part_lba==0&&mbr_lba!=0) begin part_lba<=mbr_lba;st<=BOOT_REQ;end else begin error<=1;st<=FAIL;end
     end
    end
    ROOT_MAP:begin sector_lba<=cluster_lba;sector_in_cluster<=0;st<=ret;end
    DIR_REQ:begin sec_addr<=sector_lba;sec_req<=1;off<=0;st<=DIR;end
    DIR:begin
     if(sec_valid) begin
      case(off[4:0])
       0:begin name_match<=sec_data==8'h42;entry_cluster<=0;entry_size<=0;attr<=0;end
       1:if(sec_data!=8'h47)name_match<=0;2:if(sec_data!=8'h4d)name_match<=0;
       3,4,5,6,7:if(sec_data!=8'h20)name_match<=0;
       8:if(sec_data!=8'h50)name_match<=0;9:if(sec_data!=8'h43)name_match<=0;10:if(sec_data!=8'h4d)name_match<=0;
       11:attr<=sec_data;20:entry_cluster[23:16]<=sec_data;21:entry_cluster[31:24]<=sec_data;
       26:entry_cluster[7:0]<=sec_data;27:entry_cluster[15:8]<=sec_data;
       28:entry_size[7:0]<=sec_data;29:entry_size[15:8]<=sec_data;30:entry_size[23:16]<=sec_data;
       31:if(name_match&&!attr[4]&&!attr[3]&&entry_cluster>=2&&{sec_data,entry_size[23:0]}>=4) begin start_cluster<=entry_cluster;file_size<={sec_data,entry_size[23:0]};found<=1;end
      endcase off<=off+1'b1;
     end
     if(sec_end) begin sec_req<=0;
      if(found) begin current_cluster<=start_cluster;remaining<=file_size;pack_phase<=0;ready<=1;ret<=PLAY_WAIT;st<=ROOT_MAP;end
      else if(sector_in_cluster+1<spc) begin sector_in_cluster<=sector_in_cluster+1'b1;sector_lba<=sector_lba+1'b1;st<=DIR_REQ;end
      else begin ret<=DIR_REQ;fat_off<={current_cluster[6:0],2'b0};fat_value<=0;st<=FAT_REQ;end
     end
    end
    FAT_REQ:begin sec_addr<=fat_base+(current_cluster>>7);sec_req<=1;off<=0;st<=FAT;end
    FAT:begin
     if(sec_valid) begin if(off==fat_off)fat_value[7:0]<=sec_data;if(off==fat_off+1)fat_value[15:8]<=sec_data;if(off==fat_off+2)fat_value[23:16]<=sec_data;if(off==fat_off+3)fat_value[31:24]<=sec_data;off<=off+1'b1;end
     if(sec_end) begin sec_req<=0;if(next_cluster<2||next_cluster>=32'h0ffffff8||next_cluster==current_cluster)begin error<=1;st<=FAIL;end else begin current_cluster<=next_cluster;st<=ROOT_MAP;end end
    end
    PLAY_WAIT:if(remaining==0) begin current_cluster<=start_cluster;remaining<=file_size;ret<=PLAY_WAIT;st<=ROOT_MAP;end
              else if(space_sector&&!fifo_full) st<=PLAY_REQ;
    PLAY_REQ:begin sec_addr<=sector_lba;sec_req<=1;off<=0;st<=PLAY;end
    PLAY:begin
     if(sec_valid&&remaining!=0) begin
      remaining<=remaining-1'b1;
      case(pack_phase) 0:begin pack[7:0]<=sec_data;pack_phase<=1;end 1:begin pack[15:8]<=sec_data;pack_phase<=2;end
       2:begin pack[23:16]<=sec_data;pack_phase<=3;end 3:begin fifo_din<={sec_data,pack};fifo_we<=1'b1;pack_phase<=0;end endcase
     end
     if(sec_end) begin sec_req<=0;
      if(remaining==0) st<=PLAY_WAIT;
      else if(sector_in_cluster+1<spc)begin sector_in_cluster<=sector_in_cluster+1'b1;sector_lba<=sector_lba+1'b1;st<=PLAY_WAIT;end
      else begin ret<=PLAY_WAIT;fat_off<={current_cluster[6:0],2'b0};fat_value<=0;st<=FAT_REQ;end
     end
    end
    FAIL:begin sec_req<=0;error<=1;end
    default:st<=FAIL;
   endcase
  end
 end
endmodule
