// Lightweight 16-bar spectrum overlay. The measured eight bands are paired.
// Thin 18-pixel bars and a cool cyan/blue/violet palette leave more of the
// museum image visible than the original 32-pixel traffic-light style bars.
module spectrum_overlay(input clk,input rst,input enable,input vs_in,input de_in,input [23:0] rgb_in,input [111:0] levels_async,
 output reg vs_out,output reg de_out,output reg [23:0] rgb_out);
 reg [111:0] levels1,levels2;reg [9:0] x,y;reg vs_d;reg [3:0] band;reg [6:0] level;
 reg inside;reg [23:0] color;
 wire [7:0] mix_r={1'b0,rgb_in[23:17]}+{1'b0,color[23:17]};
 wire [7:0] mix_g={1'b0,rgb_in[15:9]}+{1'b0,color[15:9]};
 wire [7:0] mix_b={1'b0,rgb_in[7:1]}+{1'b0,color[7:1]};
 always @* begin
  band=x/40;level=levels2[band*7 +: 7];
  inside=enable&&de_in&&y>=10'd326&&y<10'd426&&x<640&&(x%40)<18&&y>=10'd426-level;
  if(y<10'd360)color=24'hb65cff;
  else if(y<10'd394)color=24'h4b86ff;
  else color=24'h28dfd0;
 end
 always @(posedge clk or posedge rst) begin
  if(rst)begin levels1<=0;levels2<=0;x<=0;y<=0;vs_d<=0;vs_out<=0;de_out<=0;rgb_out<=0;end else begin
   levels1<=levels_async;levels2<=levels1;vs_d<=vs_in;
   if(vs_in&&!vs_d)begin x<=0;y<=0;end else if(de_in)begin if(x==639)begin x<=0;if(y<479)y<=y+1'b1;end else x<=x+1'b1;end
   vs_out<=vs_in;de_out<=de_in;
   if(inside)rgb_out<={mix_r,mix_g,mix_b};else rgb_out<=rgb_in;
  end
 end
endmodule
