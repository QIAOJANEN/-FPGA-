// Three-client sector arbiter. Priority protects narration first, then BGM,
// while every client releases its level request after one 512-byte sector.
module sd_read_arbiter3(
 input clk,rst,
 input bmp_req,input [31:0] bmp_addr,output bmp_valid,output [7:0] bmp_data,output bmp_end,
 input bgm_req,input [31:0] bgm_addr,output bgm_valid,output [7:0] bgm_data,output bgm_end,
 input nar_req,input [31:0] nar_addr,output nar_valid,output [7:0] nar_data,output nar_end,
 output sd_req,output [31:0] sd_addr,input sd_valid,input [7:0] sd_data,input sd_end);
 reg active,drain; reg [1:0] owner; reg [31:0] address;
 assign sd_req=active; assign sd_addr=address;
 assign bmp_valid=sd_valid&&active&&(owner==0); assign bmp_end=sd_end&&active&&(owner==0); assign bmp_data=sd_data;
 assign bgm_valid=sd_valid&&active&&(owner==1); assign bgm_end=sd_end&&active&&(owner==1); assign bgm_data=sd_data;
 assign nar_valid=sd_valid&&active&&(owner==2); assign nar_end=sd_end&&active&&(owner==2); assign nar_data=sd_data;
 wire owner_released=(owner==0)?!bmp_req:(owner==1)?!bgm_req:!nar_req;
 always @(posedge clk or posedge rst) begin
  if(rst) begin active<=0;drain<=0;owner<=0;address<=0;end
  else begin
   if(active&&sd_end) begin active<=0;drain<=1;end
   else if(drain) begin if(owner_released)drain<=0;end
   else if(!active) begin
    if(nar_req)begin active<=1;owner<=2;address<=nar_addr;end
    else if(bgm_req)begin active<=1;owner<=1;address<=bgm_addr;end
    else if(bmp_req)begin active<=1;owner<=0;address<=bmp_addr;end
   end
  end
 end
endmodule
