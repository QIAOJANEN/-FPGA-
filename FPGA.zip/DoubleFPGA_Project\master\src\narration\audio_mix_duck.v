// During narration, keep speech at full level and attenuate BGM to 1/4 (-12 dB).
// Saturation prevents signed overflow from turning peaks into harsh noise.
module audio_mix_duck(
 input clk,rst,input bgm_pulse,input [23:0] bgm_left,bgm_right,
 input [23:0] nar_left,nar_right,input narration_playing,
 output reg sample_toggle,output reg sample_pulse,
 output reg [23:0] left_sample,right_sample);
 reg signed [24:0] mix_l,mix_r;
 wire signed [23:0] b_l=bgm_left,b_r=bgm_right,n_l=nar_left,n_r=nar_right;
 wire signed [23:0] bgm_quiet_l=b_l>>>2;
 wire signed [23:0] bgm_quiet_r=b_r>>>2;
 wire signed [24:0] sum_l={n_l[23],n_l}+{bgm_quiet_l[23],bgm_quiet_l};
 wire signed [24:0] sum_r={n_r[23],n_r}+{bgm_quiet_r[23],bgm_quiet_r};
 always @(posedge clk or posedge rst) begin
  if(rst) begin sample_toggle<=0;sample_pulse<=0;left_sample<=0;right_sample<=0;mix_l<=0;mix_r<=0;end
  else begin
   sample_pulse<=0;
   if(bgm_pulse) begin
    sample_pulse<=1;sample_toggle<=~sample_toggle;
    if(narration_playing) begin
     mix_l<=sum_l;mix_r<=sum_r;
     if(sum_l>25'sh07fffff)left_sample<=24'h7fffff;
     else if(sum_l< -25'sh0800000)left_sample<=24'h800000;
     else left_sample<=sum_l[23:0];
     if(sum_r>25'sh07fffff)right_sample<=24'h7fffff;
     else if(sum_r< -25'sh0800000)right_sample<=24'h800000;
     else right_sample<=sum_r[23:0];
    end else begin left_sample<=bgm_left;right_sample<=bgm_right;end
   end
  end
 end
endmodule
