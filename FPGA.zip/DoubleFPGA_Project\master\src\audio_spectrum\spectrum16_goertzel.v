// Sixteen selected bins of a 512-sample DFT, evaluated with the Goertzel recurrence.
module spectrum16_goertzel(input clk,input rst,input sample_valid,input signed [23:0] sample,
 output reg [111:0] levels);
 reg signed [31:0] s1[0:15];reg signed [31:0] s2[0:15];
 reg signed [31:0] x;reg [3:0] band;reg [8:0] count;reg busy;integer i;
 reg signed [15:0] coeff;
 wire signed [47:0] product=coeff*s1[band];
 wire signed [47:0] accum=(x<<<14)+product-(s2[band]<<<14);
 wire signed [31:0] s0=accum>>>14;
 wire [32:0] magnitude=(s0[31]?(~s0+1'b1):s0)+(s1[band][31]?(~s1[band]+1'b1):s1[band]);
 reg [6:0] target;reg [6:0] old_level;
 always @* begin
  case(band)
   0:coeff=16'sd32766;1:coeff=16'sd32758;2:coeff=16'sd32746;3:coeff=16'sd32729;
   4:coeff=16'sd32679;5:coeff=16'sd32610;6:coeff=16'sd32470;7:coeff=16'sd32214;
   8:coeff=16'sd31686;9:coeff=16'sd30715;10:coeff=16'sd28899;11:coeff=16'sd25583;
   12:coeff=16'sd19841;13:coeff=16'sd11039;14:coeff=16'sd0;default:coeff=-16'sd25330;
  endcase
  if(magnitude[32:25]!=0) target=7'd100;
  else if(magnitude[24])target=7'd94;else if(magnitude[23])target=7'd88;else if(magnitude[22])target=7'd82;
  else if(magnitude[21])target=7'd76;else if(magnitude[20])target=7'd70;else if(magnitude[19])target=7'd64;
  else if(magnitude[18])target=7'd58;else if(magnitude[17])target=7'd52;else if(magnitude[16])target=7'd46;
  else if(magnitude[15])target=7'd40;else if(magnitude[14])target=7'd34;else if(magnitude[13])target=7'd28;
  else if(magnitude[12])target=7'd22;else if(magnitude[11])target=7'd16;else if(magnitude[10])target=7'd10;else target=0;
  old_level=levels[band*7 +: 7];
 end
 always @(posedge clk or posedge rst) begin
  if(rst)begin levels<=0;band<=0;count<=0;busy<=0;x<=0;for(i=0;i<16;i=i+1)begin s1[i]<=0;s2[i]<=0;end end
  else begin
   if(sample_valid&&!busy)begin x<={{16{sample[23]}},sample[23:8]};band<=0;busy<=1;end
   else if(busy)begin
    if(count==9'd511)begin
     if(target>old_level)levels[band*7 +: 7]<=target;
     else if(old_level>2)levels[band*7 +: 7]<=old_level-2;else levels[band*7 +: 7]<=0;
     s1[band]<=0;s2[band]<=0;
    end else begin s2[band]<=s1[band];s1[band]<=s0;end
    if(band==15)begin band<=0;busy<=0;if(count==511)count<=0;else count<=count+1'b1;end else band<=band+1'b1;
   end
  end
 end
endmodule
