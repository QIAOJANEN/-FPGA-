module pcm_audio_player(
 input mclk,input rst,input fifo_empty,output reg fifo_rd,input [31:0] fifo_data,input fifo_valid,
 output reg sample_toggle,output reg [23:0] left_sample,output reg [23:0] right_sample,output reg sample_pulse);
 reg [7:0] div;
 always @(posedge mclk or posedge rst) begin
  if(rst) begin div<=0;fifo_rd<=0;sample_toggle<=0;left_sample<=0;right_sample<=0;sample_pulse<=0;end else begin
   fifo_rd<=0;sample_pulse<=0;
   if(div==8'd255) begin div<=0;if(!fifo_empty) fifo_rd<=1;end else div<=div+1'b1;
   if(fifo_valid) begin left_sample<={fifo_data[15:0],8'h00};right_sample<={fifo_data[31:16],8'h00};sample_toggle<=~sample_toggle;sample_pulse<=1;end
  end
 end
endmodule

module audio_sample_cdc(input clk,input rst,input sample_toggle_async,input [23:0] left_async,right_async,
 output reg valid,output reg [23:0] left,right);
 reg [2:0] ts;reg [23:0] l1,r1;
 always @(posedge clk or posedge rst) begin
  if(rst) begin ts<=0;l1<=0;r1<=0;left<=0;right<=0;valid<=0;end else begin
   ts<={ts[1:0],sample_toggle_async};l1<=left_async;r1<=right_async;valid<=ts[2]^ts[1];
   if(ts[2]^ts[1]) begin left<=l1;right<=r1;end
  end
 end
endmodule
