// Two SDRAM buffers, fourteen files. Payload stays stable until swap acknowledgement.
module playlist14_legacy #(
    parameter integer CLK_HZ = 100000000,
    parameter integer COVER_SECONDS = 12,
    parameter integer IMAGE_SECONDS = 5
)(
    input clk, rst, catalog_ready, source_done, source_error,
    input write_finish_toggle, next_press, prev_press, auto_press, scale_change_toggle,
    input narration_enable, narration_busy,
    input swap_ack_toggle,
    output reg load_start,
    output reg [3:0] load_index,
    output reg [1:0] write_buf_idx,
    output reg swap_toggle,
    output reg [1:0] swap_buffer,
    output reg [3:0] swap_image,
    output reg auto_enabled,
    output reg [3:0] current_image,
    output reg display_started,
    output wire fault
);
localparam BOOT=0, LOADING=1, READY=2, SWAPPING=3, FAILED=4;
reg [2:0] state;
reg [2:0] finish_sync, ack_sync;
reg source_seen, finish_seen, next_pending, prev_pending;
reg [2:0] scale_sync;
reg scale_pending,reload_active,reload_ready;
reg [31:0] seconds_div;
reg [3:0] seconds_count;
wire finished = finish_sync[2] ^ finish_sync[1];
wire scale_event = scale_sync[2] ^ scale_sync[1];
// Keep the normal minimum dwell time, but do not interrupt an enabled narration.
// Manual next_press remains an immediate override in the READY state below.
wire auto_due = auto_enabled && !auto_press && display_started &&
                (seconds_count >= ((current_image == 0) ? COVER_SECONDS : IMAGE_SECONDS)) &&
                (!narration_enable || !narration_busy);
assign fault = state == FAILED;
always @(posedge clk or posedge rst) begin
    if (rst) begin
        state<=BOOT; finish_sync<=0; ack_sync<=0;
        source_seen<=0; finish_seen<=0; next_pending<=0; prev_pending<=0;
        scale_sync<=0;scale_pending<=0;reload_active<=0;reload_ready<=0;
        seconds_div<=0; seconds_count<=0;
        load_start<=0; load_index<=0; write_buf_idx<=0;
        swap_toggle<=0; swap_buffer<=0; swap_image<=0;
        auto_enabled<=0; current_image<=0; display_started<=0;
    end else begin
        finish_sync <= {finish_sync[1:0],write_finish_toggle};
        ack_sync <= {ack_sync[1:0],swap_ack_toggle};
        scale_sync <= {scale_sync[1:0],scale_change_toggle};
        if(scale_event) scale_pending<=1;
        load_start <= 0;
        if (auto_press) begin
            auto_enabled <= ~auto_enabled;
            seconds_div<=0; seconds_count<=0;
        end else if (auto_enabled && display_started && !auto_due) begin
            if (seconds_div == CLK_HZ-1) begin
                seconds_div<=0;
                if(seconds_count!=4'hf) seconds_count<=seconds_count+1'b1;
            end else seconds_div<=seconds_div+1'b1;
        end
        // A press during prefetch is remembered; repeated presses coalesce to one.
        if (next_press) next_pending<=1;
        if (prev_press) prev_pending<=1;
        case (state)
        BOOT: if (catalog_ready) begin
            load_index<=0; write_buf_idx<=0; load_start<=1;
            source_seen<=0; finish_seen<=0; state<=LOADING;
        end
        LOADING: begin
            if (source_done) source_seen<=1;
            if (finished) finish_seen<=1;
            if (source_error) state<=FAILED;
            else if ((source_seen || source_done) && (finish_seen || finished)) begin
                if(reload_active)reload_ready<=1;
                state<=READY;
            end
        end
        READY: if((prev_pending||prev_press) && display_started && !reload_ready)begin
            // The free buffer normally contains the next image. Replace it with
            // the previous image, then commit that buffer through reload_ready.
            load_index<=(current_image==0)?4'd13:current_image-1'b1;
            load_start<=1;source_seen<=0;finish_seen<=0;
            prev_pending<=0;next_pending<=0;reload_active<=1;state<=LOADING;
        end else if(scale_pending && display_started && !reload_ready)begin
            // Discard the prefetched next frame and rebuild the currently shown
            // picture into that free buffer using the newly selected scale.
            load_index<=current_image;load_start<=1;source_seen<=0;finish_seen<=0;
            scale_pending<=0;reload_active<=1;state<=LOADING;
        end else if (!display_started || reload_ready || next_pending || next_press || auto_due) begin
            swap_buffer<=write_buf_idx;
            swap_image<=load_index;
            swap_toggle<=~swap_toggle;
            // The initial cover commit must not consume a press queued while
            // the first image was loading. That press advances AFTER the cover.
            if (display_started) begin next_pending<=0;prev_pending<=0;end
            state<=SWAPPING;
        end
        SWAPPING: if (ack_sync[2] == swap_toggle) begin
            current_image<=load_index;
            display_started<=1;
            seconds_div<=0; seconds_count<=0;
            // The video reader has acknowledged its NEW buffer. Only now reuse old one.
            write_buf_idx<={1'b0,~write_buf_idx[0]};
            load_index<=(load_index==13) ? 0 : load_index+1'b1;
            load_start<=1; source_seen<=0; finish_seen<=0;
            reload_active<=0;reload_ready<=0;
            state<=LOADING;
        end
        FAILED: ; // Keep last committed picture, require K1 after correcting the card.
        default: state<=BOOT;
        endcase
    end
end
endmodule

// Four-buffer adjacent-image cache. Current/previous/next images remain resident;
// the fourth buffer follows the last navigation direction for quick repeated keys.
module playlist14 #(
 parameter integer CLK_HZ=100000000,COVER_SECONDS=12,IMAGE_SECONDS=5
)(
 input clk,rst,catalog_ready,source_done,source_error,
 input write_finish_toggle,next_press,prev_press,auto_press,scale_change_toggle,
 input narration_enable,narration_busy,swap_ack_toggle,
 output reg load_start,output reg [3:0] load_index,output reg [1:0] write_buf_idx,
 output reg swap_toggle,output reg [1:0] swap_buffer,output reg [3:0] swap_image,
 output reg auto_enabled,output reg [3:0] current_image,output reg display_started,
 output wire fault
);
 localparam BOOT=0,LOADING=1,READY=2,SWAPPING=3,FAILED=4;
 localparam NAV_NONE=0,NAV_NEXT=1,NAV_PREV=2;
 reg [2:0] state;reg [2:0] finish_sync,ack_sync;
 reg source_seen,finish_seen,load_for_swap;
 reg [1:0] nav_pending,last_direction;
 reg [31:0] seconds_div;reg [3:0] seconds_count;
 reg [3:0] cache_valid;
 reg [3:0] cache_img0,cache_img1,cache_img2,cache_img3;
 wire finished=finish_sync[2]^finish_sync[1];
 reg [3:0] next_image,prev_image,next2_image,prev2_image;
 function cache_hit;input [3:0] img;begin case(img[1:0])
  0:cache_hit=cache_valid[0]&&(cache_img0==img);
  1:cache_hit=cache_valid[1]&&(cache_img1==img);
  2:cache_hit=cache_valid[2]&&(cache_img2==img);
  default:cache_hit=cache_valid[3]&&(cache_img3==img);
 endcase end endfunction
 wire auto_due=auto_enabled&&!auto_press&&display_started&&
  (seconds_count>=((current_image==0)?COVER_SECONDS:IMAGE_SECONDS))&&
  (!narration_enable||!narration_busy);
 assign fault=state==FAILED;
 always @(posedge clk or posedge rst)begin
  if(rst)begin
   state<=BOOT;finish_sync<=0;ack_sync<=0;source_seen<=0;finish_seen<=0;load_for_swap<=0;
   nav_pending<=NAV_NONE;last_direction<=NAV_NEXT;seconds_div<=0;seconds_count<=0;
   cache_valid<=0;cache_img0<=0;cache_img1<=0;cache_img2<=0;cache_img3<=0;
   next_image<=1;prev_image<=13;next2_image<=2;prev2_image<=12;
   load_start<=0;load_index<=0;write_buf_idx<=0;swap_toggle<=0;swap_buffer<=0;swap_image<=0;
   auto_enabled<=0;current_image<=0;display_started<=0;
  end else begin
   finish_sync<={finish_sync[1:0],write_finish_toggle};ack_sync<={ack_sync[1:0],swap_ack_toggle};load_start<=0;
   if(auto_press)begin auto_enabled<=~auto_enabled;seconds_div<=0;seconds_count<=0;end
   else if(auto_enabled&&display_started&&!auto_due)begin
    if(seconds_div==CLK_HZ-1)begin seconds_div<=0;if(seconds_count!=4'hf)seconds_count<=seconds_count+1'b1;end
    else seconds_div<=seconds_div+1'b1;
   end
   if(prev_press)nav_pending<=NAV_PREV;else if(next_press)nav_pending<=NAV_NEXT;
   case(state)
    BOOT:if(catalog_ready)begin load_index<=0;write_buf_idx<=0;cache_valid[0]<=0;load_for_swap<=1;
     load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
    LOADING:begin
     if(source_done)source_seen<=1;if(finished)finish_seen<=1;
     if(source_error)state<=FAILED;
     else if((source_seen||source_done)&&(finish_seen||finished))begin
      case(write_buf_idx)
       0:begin cache_img0<=load_index;cache_valid[0]<=1;end
       1:begin cache_img1<=load_index;cache_valid[1]<=1;end
       2:begin cache_img2<=load_index;cache_valid[2]<=1;end
       default:begin cache_img3<=load_index;cache_valid[3]<=1;end
      endcase
      if(load_for_swap)begin swap_buffer<=write_buf_idx;swap_image<=load_index;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else state<=READY;
     end
    end
    READY:begin
     if((nav_pending==NAV_PREV)||prev_press)begin
      nav_pending<=NAV_NONE;last_direction<=NAV_PREV;
      if(cache_hit(prev_image))begin swap_buffer<=prev_image[1:0];swap_image<=prev_image;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else begin load_index<=prev_image;write_buf_idx<=prev_image[1:0];cache_valid[prev_image[1:0]]<=0;load_for_swap<=1;
       load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
     end else if((nav_pending==NAV_NEXT)||next_press||auto_due)begin
      nav_pending<=NAV_NONE;last_direction<=NAV_NEXT;
      if(cache_hit(next_image))begin swap_buffer<=next_image[1:0];swap_image<=next_image;swap_toggle<=~swap_toggle;state<=SWAPPING;end
      else begin load_index<=next_image;write_buf_idx<=next_image[1:0];cache_valid[next_image[1:0]]<=0;load_for_swap<=1;
       load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
     end else if(!cache_hit(next_image))begin load_index<=next_image;write_buf_idx<=next_image[1:0];cache_valid[next_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end else if(!cache_hit(prev_image))begin load_index<=prev_image;write_buf_idx<=prev_image[1:0];cache_valid[prev_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end else if((last_direction==NAV_NEXT)&&!cache_hit(next2_image))begin load_index<=next2_image;write_buf_idx<=next2_image[1:0];cache_valid[next2_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;
     end else if((last_direction==NAV_PREV)&&!cache_hit(prev2_image))begin load_index<=prev2_image;write_buf_idx<=prev2_image[1:0];cache_valid[prev2_image[1:0]]<=0;load_for_swap<=0;
      load_start<=1;source_seen<=0;finish_seen<=0;state<=LOADING;end
    end
    SWAPPING:if(ack_sync[2]==swap_toggle)begin
     current_image<=swap_image;display_started<=1;seconds_div<=0;seconds_count<=0;load_for_swap<=0;
     next_image<=(swap_image==13)?0:swap_image+1'b1;
     prev_image<=(swap_image==0)?13:swap_image-1'b1;
     next2_image<=(swap_image>=12)?swap_image-12:swap_image+2'd2;
     prev2_image<=(swap_image<2)?swap_image+4'd12:swap_image-2'd2;
     state<=READY;
    end
    FAILED:;
    default:state<=BOOT;
   endcase
  end
 end
endmodule
