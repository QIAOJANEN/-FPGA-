# 双 EG4S20 主从博物馆展示工程

本目录包含两个独立的 Tang Dynasty 6.2 工程：

- `master/src/td_project/DoubleFPGA_Master.al`：主板。保留原按键、拨码、SD 图片、SDRAM、数码管、字幕、频谱和 HDMI 输出；音频改为接收从板 I2S，并支持把不同尺寸的 24-bit BMP 硬件重采样为 640×480。
- `slave/src/td_project/DoubleFPGA_Slave.al`：从板。SD 卡只读取 `BGM.PCM` 与 `N00.PCM`~`N13.PCM`，按主板发来的图片编号播放并把 PCM 以 I2S 返回。

已经完成布局布线的下载文件位于 `output/DoubleFPGA_Master.bit` 和 `output/DoubleFPGA_Slave.bit`；构建摘要与 SHA-256 见 `output/BUILD_REPORT.md`。

SW3 用于显示原始分辨率提示；主板会解析 BMP 文件头和行补齐，将宽度 1～2048、高度 1～4095 的正高度 24-bit 无压缩 BMP 以最近邻方式强制重采样为 640×480。

## 接线

两块板断电接线，所有信号均为 3.3 V LVCMOS：

| 主板 J1 | 主板信号 | 从板 J1 | 从板信号 | 方向 |
|---|---|---|---|---|
| 2 / GPIOA1 | `link_cmd_tx` | 2 / GPIOA1 | `link_cmd_rx` | 主 -> 从 |
| 3 / GPIOA2 | `link_i2s_bclk` | 3 / GPIOA2 | `link_i2s_bclk` | 从 -> 主 |
| 4 / GPIOA3 | `link_i2s_lrck` | 4 / GPIOA3 | `link_i2s_lrck` | 从 -> 主 |
| 5 / GPIOA4 | `link_i2s_data` | 5 / GPIOA4 | `link_i2s_data` | 从 -> 主 |
| 6 / GPIOA5 | `link_audio_busy` | 6 / GPIOA5 | `link_audio_busy` | 从 -> 主；115200-baud 状态帧（busy、频谱、BGM） |
| 12 / GND | GND | 12 / GND | GND | 必须共地 |

建议线长不超过 20 cm。不要连接两块板的 3V3 或 5V；两板各自供电，只连接信号和地。

## SD 卡内容

主板卡必须为 FAT32，根目录保留 `00.BMP`~`13.BMP`。图片须为正高度、24-bit、无压缩 BMP；允许不同分辨率，主板会自动输出为 640×480。

从板卡必须为 FAT32，根目录放置：

```text
BGM.PCM
N00.PCM
N01.PCM
...
N13.PCM
```

PCM 格式为 48000 Hz、立体声、16-bit signed little-endian、无文件头。可直接把当前 G 盘根目录中的这些 PCM 文件复制到从板卡。主板卡上的 PCM 可保留，但主板逻辑不会读取它们。

## 操作保持不变

- KEY1：复位；K2：下一张；K3：自动轮播开关；K4：上一张（SW2 模式下为降低对比度）。
- SW1：讲解音频和字幕；SW2：亮度/对比度模式；SW3：分辨率提示。
- 从板 SW1：开启/关闭主板 HDMI 画面上的 RGB 音频频谱柱；从板 SW2：开启/关闭背景音乐，讲解音频不受影响。
- 所有按键/拨码只接主板。从板无需人工操作，LED 显示其 SD/音频状态码（低有效）。
- 自动轮播达到最低停留时间后会等待从板状态帧中的 busy 位清零，确保当前讲解真正播放完毕；已预加载的相邻图片可立即开始手动转场，缓存未命中时保持当前画面直至目标帧完整。
- 主板 SW4 是整个双板工程的总开关（拨到 ON/低电平时运行）。关闭后主板图像、字幕、SD/SDRAM 播放链路复位，并持续通知从板停止解说；重新开启后从封面重新启动。

## 下载顺序

1. 在 TD 6.2 打开并编译从板工程，下载到从板。
2. 打开并编译主板工程，下载到主板。
3. 两板断电完成 J1 接线并插入各自 SD 卡。
4. 先上电从板，再上电主板。控制帧每 1 ms 重发，所以先后顺序并非功能要求，但此顺序便于观察从板初始化。
