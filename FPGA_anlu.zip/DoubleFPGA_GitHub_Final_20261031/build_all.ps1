param(
    [string]$TdCommand = $env:TD_COMMAND
)

$ErrorActionPreference = 'Stop'
$projectRoot = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($TdCommand)) {
    $detected = Get-Command 'td_commands_prompt.exe' -ErrorAction SilentlyContinue
    if ($detected) { $TdCommand = $detected.Source }
}
if ([string]::IsNullOrWhiteSpace($TdCommand) -or -not (Test-Path -LiteralPath $TdCommand)) {
    throw "Tang Dynasty command tool not found. Pass -TdCommand with its full path or set TD_COMMAND."
}

$projects = @(
    (Join-Path $projectRoot 'slave\src\td_project'),
    (Join-Path $projectRoot 'master\src\td_project')
)
foreach ($project in $projects) {
    Push-Location $project
    try {
        $script = (Join-Path $project 'build_bitstream.tcl').Replace('\','/')
        & $TdCommand $script
        if ($LASTEXITCODE -ne 0) { throw "TD failed in $project" }
    }
    finally { Pop-Location }
}
