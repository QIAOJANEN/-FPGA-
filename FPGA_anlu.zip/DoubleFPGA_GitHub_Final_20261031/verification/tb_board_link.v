`timescale 1ns/1ps
module tb_board_link;
 reg clk=0,rst=1,enable=0;reg [3:0] image=0;wire serial;
 wire rx_enable,rx_toggle;wire [3:0] rx_image;
 reg status_audio_busy=1,status_spectrum_enable=1,status_bgm_enable=1;
 wire status_serial;
 wire decoded_audio_busy,decoded_spectrum_enable,decoded_bgm_enable,status_valid;
 always #50 clk=~clk; // 10 MHz
 master_control_uart_tx #(.CLK_HZ(10_000_000),.BAUD(1_000_000)) tx(
  .clk(clk),.rst(rst),.narration_enable(enable),.image_index(image),.tx(serial));
 slave_control_uart_rx #(.CLK_HZ(10_000_000),.BAUD(1_000_000)) rx(
  .clk(clk),.rst(rst),.rx(serial),.narration_enable(rx_enable),.image_index(rx_image),.command_toggle(rx_toggle));
 slave_status_uart_tx #(.CLK_HZ(10_000_000),.BAUD(1_000_000),.REFRESH_BITS(8)) status_tx(
  .clk(clk),.rst(rst),.audio_busy(status_audio_busy),.spectrum_enable(status_spectrum_enable),
  .bgm_enable(status_bgm_enable),.tx(status_serial));
 master_status_uart_rx #(.CLK_HZ(10_000_000),.BAUD(1_000_000)) status_rx(
  .clk(clk),.rst(rst),.rx(status_serial),.audio_busy(decoded_audio_busy),
  .spectrum_enable(decoded_spectrum_enable),.bgm_enable(decoded_bgm_enable),.status_valid(status_valid));
 initial begin
  #500 rst=0; enable=1;image=4'd9;
  wait(rx_toggle===1'b1); #200;
  if(rx_enable!==1'b1 || rx_image!==4'd9) $fatal(1,"command mismatch");
  $display("PASS: master/slave control frame enable=%0d image=%0d",rx_enable,rx_image);
  wait(status_valid===1'b1); #200;
  if(decoded_audio_busy!==1'b1 || decoded_spectrum_enable!==1'b1 || decoded_bgm_enable!==1'b1)
   $fatal(1,"initial status mismatch");
  status_audio_busy=0;status_spectrum_enable=0;status_bgm_enable=0;
  wait(decoded_audio_busy===1'b0 && decoded_spectrum_enable===1'b0 && decoded_bgm_enable===1'b0);
  $display("PASS: slave/master status frame busy=%0d spectrum=%0d bgm=%0d",
   decoded_audio_busy,decoded_spectrum_enable,decoded_bgm_enable);
  $finish;
 end
 initial begin #5000000;$fatal(1,"timeout");end
endmodule
