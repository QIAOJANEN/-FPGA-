# GitHub 发布包说明

本目录为双 FPGA 智慧博物馆导览系统的最终 GitHub 发布版本，整理日期为 2026-10-31。

## 目录

- `master/`：主板完整 Tang Dynasty 工程与 HDL/IP/约束文件。
- `slave/`：从板完整 Tang Dynasty 工程与 HDL/IP/约束文件。
- `output/`：主板、从板最终 bit 文件及构建报告。
- `verification/`：板间正向控制 UART 与反向状态 UART 验证平台。
- `build_all.ps1`：主从工程一键构建脚本。
- `SHA256SUMS.txt`：主板与从板 BIT 的 SHA-256 校验值。

## 已排除内容

发布包不包含技术文档、作品海报、布局布线缓存、运行目录、SD 卡备份、日志、临时文件和未被工程引用的示例音频素材。SD 卡中的图片、讲解 PCM 和背景音乐文件不随源码仓库发布。

## 使用提示

使用安路 Tang Dynasty 6.2 打开：

- `master/src/td_project/DoubleFPGA_Master.al`
- `slave/src/td_project/DoubleFPGA_Slave.al`

两个 bit 必须配套使用。主板用于 HDMI、图片 SD 卡和按键控制；从板用于讲解音频与背景音乐 SD 卡。

上传 GitHub 时，将本目录内的文件和文件夹作为仓库根目录上传即可，不要再套一层同名目录。
